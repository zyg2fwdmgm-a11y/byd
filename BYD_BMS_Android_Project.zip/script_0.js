
(()=>{'use strict';
const $=id=>document.getElementById(id),FALLBACK_AH=24,REFRESH_MS=250;
const SERVICE='6e400001-b5a3-f393-e0a9-e50e24dcca9e',WRITE='6e400002-b5a3-f393-e0a9-e50e24dcca9e',NOTIFY='6e400003-b5a3-f393-e0a9-e50e24dcca9e';
let connected=false,lastData=null,logs=[],toastTimer=null,lastReadAt=0,webDevice=null,webServer=null,tx=null,rx=null,webPollTimer=null,readBusy=false,pending=null,lastRawHex='',lastFrames=[],readHistory=[],nativeDevices=[],notifyRecords=[],orphanNotifications=[];
let tripState=null,tripArmed=true,tripClockTimer=null,amapPromise=null,mapCoordQueue=Promise.resolve(),liveMapState=null,summaryMapState=null,viewingSavedTrip=false;
let chargeCurrentSamples=[];
function toast(s){const el=$('toast');el.textContent=s;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600)}
function log(s){const t=new Date().toLocaleTimeString();logs.push(`${t}  ${s}`);if(logs.length>200)logs.shift();$('log').textContent=logs.slice(-80).join('\n');$('log').scrollTop=$('log').scrollHeight}
function native(){return !!window.BmsNative}
function updateChargingEta(currentA,soc,remainingAh,ratedAh){
  const card=$('chargingEta');
  const isCharging=Number.isFinite(currentA)&&currentA>0.25&&Number.isFinite(remainingAh)&&Number.isFinite(ratedAh)&&ratedAh>0&&remainingAh<ratedAh-0.05&&(Number(soc)||0)<99.5;
  if(!isCharging){chargeCurrentSamples=[];card.hidden=true;return;}
  chargeCurrentSamples.push(currentA);if(chargeCurrentSamples.length>12)chargeCurrentSamples.shift();
  const avgA=chargeCurrentSamples.reduce((a,b)=>a+b,0)/chargeCurrentSamples.length;
  const leftAh=Math.max(0,ratedAh-remainingAh);
  if(leftAh<=0.05||avgA<=0.25){card.hidden=true;return;}
  const mins=Math.max(1,Math.round(leftAh/avgA*60));
  const h=Math.floor(mins/60),m=mins%60;
  const now=new Date(),finishAt=new Date(now.getTime()+mins*60000);const hh=String(finishAt.getHours()).padStart(2,'0'),mm=String(finishAt.getMinutes()).padStart(2,'0');const dayDelta=Math.floor(Date.UTC(finishAt.getFullYear(),finishAt.getMonth(),finishAt.getDate())/86400000)-Math.floor(Date.UTC(now.getFullYear(),now.getMonth(),now.getDate())/86400000);const finishDay=dayDelta===1?'次日 ':dayDelta>1?`${finishAt.getMonth()+1}-${String(finishAt.getDate()).padStart(2,'0')} `:'';$('chargingEtaValue').textContent=(h>0?`约 ${h}小时${m?m+'分':''}`:`约 ${m} 分钟`)+`（预计 ${finishDay}${hh}:${mm} 充满）`;
  card.hidden=false;
}
function status(on,title,caption,name){connected=!!on;$('statusDot').classList.toggle('on',connected);$('topStatus').textContent=connected?'已连接':(title||'未连接');$('topDevice').textContent=name||'FD042884';$('livePill').textContent=connected?'● 实时监控':'● 未连接';$('scanBtn').disabled=connected;$('scanBtn').textContent=connected?'已连接':'扫描并连接';$('readBtn').disabled=!connected;$('disconnectBtn').disabled=!connected;if(name)$('topDevice').textContent=name;
  $('reconnectHint').hidden=connected||title!=='重连暂停';if(connected){$('temperatureStatus').textContent='正在读取';}else{$('temperatureStatus').textContent='等待读取';$('topAge').textContent='等待数据';}if(native()&&connected){window.BmsNative.setAutoRefresh(true);log('蓝牙连接保持不变，已开启持续循环读取（每轮完成后短暂停顿）。')}if(native()&&!connected){window.BmsNative.setAutoRefresh(false)}}
function put(id,html){$(id).innerHTML=html}
function displayData(d){
  lastData=d;lastReadAt=Date.now();
  const soc=Number(d.soc),p=Math.max(0,Math.min(100,Number.isFinite(soc)?soc:0));
  put('socValue',`${Number.isFinite(soc)?soc.toFixed(1):'—'}<small>%</small>`);
  $('segments').querySelectorAll('i').forEach((x,i)=>x.style.width=`${Math.max(0,Math.min(100,(p-i*20)*5))}%`);
  const rated=Number(d.ratedCapacityAh)>0?Number(d.ratedCapacityAh):FALLBACK_AH;
  const rem=Number.isFinite(Number(d.remainingCapacityAh))?Number(d.remainingCapacityAh):(Number.isFinite(soc)?rated*soc/100:NaN);
  $('ratedCapacityText').textContent=Number.isInteger(rated)?String(rated):rated.toFixed(1);
  put('remainingValue',`${Number.isFinite(rem)?rem.toFixed(2):'—'}<small>Ah</small>`);
  $('capacitySource').textContent=d.capacitySource==='bms'?'BMS 实时剩余容量':'按 SOC × 24Ah 估算';
  put('voltageValue',`${Number(d.voltage).toFixed(2)}<small>V</small>`);
  put('spreadValue',`${d.spread===null||d.spread===undefined?'—':d.spread}<small>mV</small>`);
  put('cycleValue',`${Number.isFinite(Number(d.cycleCount))?d.cycleCount:'—'}<small>次</small>`);
  const soh=d.sohPercent!==null&&d.sohPercent!==undefined&&Number.isFinite(Number(d.sohPercent))?Number(d.sohPercent):NaN;
  put('sohValue',`${Number.isFinite(soh)?soh.toFixed(1).replace(/\.0$/,''):'—'}<small>%</small>`);
  const current=Number(d.currentA),power=Number(d.powerW);
  updateChargingEta(current,soc,rem,rated);
  $('currentValue').innerHTML=`${Number.isFinite(current)?current.toFixed(2):'—'}<small>A</small>`;
  $('currentNote').textContent='BMS 偏移26 · 0.01A/单位';
  $('powerValue').innerHTML=`${Number.isFinite(power)?(power>=1000?Math.round(power):power.toFixed(1)):'—'}<small>W</small>`;
  $('powerNote').textContent='总电压 × 电流绝对值';
  const temps=[
    {label:'电芯',value:d.temperatures?.cell,blue:false},
    {label:'环境',value:d.temperatures?.ambient,blue:false},
    {label:'MOS',value:d.temperatures?.mos,blue:false},
    {label:'探针1',value:d.probes?.[0],blue:true},
    {label:'探针2',value:d.probes?.[1],blue:true}
  ];
  const probeValues=(d.probes||[]).slice(0,2);
  const validProbes=probeValues.filter(v=>v!==null&&v!==undefined&&Number.isFinite(Number(v))).map(Number);
  const validSensors=temps.filter(x=>x.value!==null&&x.value!==undefined&&Number.isFinite(Number(x.value))).map(x=>Number(x.value));
  $('tempGrid').innerHTML='';
  for(const t of temps){
    const chip=document.createElement('div');chip.className='temp-chip'+(t.wide?' probe4':'');
    const left=document.createElement('span');left.className='temp-left';
    const dot=document.createElement('i');dot.className='temp-dot'+(t.blue?' blue':'');
    const label=document.createElement('span');label.textContent=t.label;left.append(dot,label);
    const val=document.createElement('b');val.className='temp-val'+(t.value===null||t.value===undefined?' missing':'');
    val.textContent=t.value===null||t.value===undefined?'—':`${Number(t.value).toFixed(1)}°C`;
    chip.append(left,val);$('tempGrid').append(chip);
  }
  if(validProbes.length){
    const avg=validProbes.reduce((a,b)=>a+b,0)/validProbes.length,max=Math.max(...validProbes);
    $('averageTemp').textContent=`探针平均 ${avg.toFixed(1)}°C`;
    $('scaleDot').style.left=`${Math.max(0,Math.min(100,(avg+20)/90*100))}%`;
    put('maxTempValue',`${max.toFixed(1)}<small>°C</small>`);
    $('temperatureStatus').textContent=`${validSensors.length}/5 路已读取`;
  }else{
    $('averageTemp').textContent='探针平均 — °C';$('temperatureStatus').textContent='暂无数据';put('maxTempValue','—<small>°C</small>');
  }
  const grid=$('cellGrid');grid.innerHTML='';
  const minIndex=(d.cells.find(c=>c.mv===d.min)||{}).index,maxIndex=(d.cells.find(c=>c.mv===d.max)||{}).index;
  for(const c of d.cells){
    const el=document.createElement('div');el.className='cell';if(c.index===minIndex)el.classList.add('low');else if(c.index===maxIndex)el.classList.add('high');
    const n=document.createElement('div');n.className='n';n.textContent=`CELL ${String(c.index).padStart(2,'0')}`;
    const v=document.createElement('div');v.className='v';v.textContent=c.mv===null?'—':(c.mv/1000).toFixed(3);
    const u=document.createElement('div');u.className='u';u.textContent='V';
    const bar=document.createElement('div');bar.className='bar';const fill=document.createElement('i');
    fill.style.width=c.mv===null?'0%':`${Math.max(8,35+(c.mv-d.min)/Math.max(1,d.spread||1)*55)}%`;bar.append(fill);el.append(n,v,u,bar);grid.append(el);
  }
  $('cellCount').textContent=`${d.validCellCount}/20 有效`;
  put('minCell',d.min===null?'—':(d.min/1000).toFixed(3));put('maxCell',d.max===null?'—':(d.max/1000).toFixed(3));
  $('matchNote').textContent=d.sumMatches?`20 串合计 ${Number(d.sum).toFixed(3)} V，与总压相差 ${Number(d.delta).toFixed(3)} V。`:'单体合计与总压暂未通过校验，请导出诊断记录。';
  $('matchNote').style.color=d.sumMatches?'#80ddb7':'#ffc36a';$('topAge').textContent='刚刚更新';
  log(`读取成功：${Number(d.voltage).toFixed(2)} V / SOC ${Number(d.soc).toFixed(1)}% / SOH ${Number.isFinite(soh)?soh.toFixed(1):'—'}% / 电流 ${Number.isFinite(current)?current.toFixed(2):'—'} A / 功率 ${Number.isFinite(power)?power.toFixed(1):'—'} W / 循环 ${d.cycleCount??'—'} / 压差 ${d.spread??'—'} mV`);
  updateTripBattery(d);
  // displayData is reached only after a complete, CRC-validated 124-byte BMS read.
  checkAutoTrip(d);
}

function showDashboard(){ $('tripView').hidden=true; $('tripSummary').hidden=true; $('tripHistory').hidden=true; document.querySelector('.app').style.display='block'; $('resumeTripBtn').hidden=!tripState?.active; viewingSavedTrip=false; if(native())window.BmsNative.setTripScreenOn(false); }
function showTripPage(){ document.querySelector('.app').style.display='none'; $('tripSummary').hidden=true; $('tripHistory').hidden=true; $('tripView').hidden=false; $('resumeTripBtn').hidden=true; viewingSavedTrip=false; if(native())window.BmsNative.setTripScreenOn(true); setTimeout(()=>{loadCurrentMap();if(tripState?.points?.length)refreshTripMap();},220); }
function fmtDuration(ms){const sec=Math.max(0,Math.floor(ms/1000)),h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;return h>0?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;}
function haversine(a,b){const R=6371000,toRad=x=>x*Math.PI/180,dLat=toRad(b.lat-a.lat),dLon=toRad(b.lon-a.lon),x=Math.sin(dLat/2)**2+Math.cos(toRad(a.lat))*Math.cos(toRad(b.lat))*Math.sin(dLon/2)**2;return 2*R*Math.asin(Math.sqrt(x));}
function finiteNum(v){if(v===null||v===undefined||v==='')return null;const n=Number(v);return Number.isFinite(n)?n:null;}
const TRIP_START_POWER_W=50;
const TRIP_STOP_POWER_W=1;
function checkAutoTrip(d){
  const p=Math.abs(Number(d.powerW)||0);
  const current=Number(d.currentA);
  // BYD register convention confirmed from the supplied loaded logs: negative = discharge, positive = charge.
  const discharging=Number.isFinite(current)&&current < -0.05;
  if(tripState?.active)return;
  // Charging power must never create a ride. Rearm only when the pack is idle/discharging at <1W.
  if(!tripArmed){if(!discharging&&p<TRIP_STOP_POWER_W)tripArmed=true;return;}
  // Start on one complete CRC-validated sample at >=50W, but only in discharge direction.
  if(discharging&&p>=TRIP_START_POWER_W){tripArmed=false;startTrip(d);}
}
function startTrip(d){
  if(tripState?.active)return;
  const rem=finiteNum(d.remainingCapacityAh),soc=finiteNum(d.soc);
  tripArmed=false;
  const startVoltage=finiteNum(d.voltage)??60,startCurrent=Number(d.currentA)||0,startSignedPower=startVoltage*startCurrent;
  tripState={active:true,startAt:Date.now(),endAt:null,points:[],distanceM:0,lastPoint:null,speedKmh:0,maxSpeed:0,startSoc:soc,currentSoc:soc,startRemainingAh:rem,currentRemainingAh:rem,maxCurrent:Math.abs(startCurrent),maxPower:Math.abs(Number(d.powerW)||0),powerSum:0,powerCount:0,energyWh:0,regenWh:0,lastEnergyAt:Date.now(),lastSignedPowerW:startSignedPower,lastVoltage:startVoltage,minVoltage:finiteNum(d.voltage),maxSpread:finiteNum(d.spread),startTemp:readTripTemp(d),maxTemp:readTripTemp(d),savedToHistory:false};
  if(native())window.BmsNative.setRideActive(true);
  destroyAmapState(liveMapState); liveMapState=null;
  destroyAmapState(summaryMapState); summaryMapState=null;
  $('tripMap').innerHTML='<div id="tripMapEmpty" class="map-empty">正在加载中国地图…</div>';
  $('summaryMap').innerHTML='<div id="summaryMapEmpty" class="map-empty">本次行程暂无 GPS 轨迹</div>';
  $('resumeTripBtn').hidden=true;
  $('tripMapEmpty').textContent='正在加载中国地图并启动手机定位…'; $('gpsStatus').textContent='正在启动定位'; $('startGpsBtn').style.display='inline-block'; $('tripGpsHint').textContent='检测到电池功率达到 50W，已自动开始记录';
  showTripPage(); updateTripBattery(d); updateTripStats();
  if(native())window.BmsNative.startLocationTracking(); else startBrowserLocation();
  clearInterval(tripClockTimer);tripClockTimer=setInterval(updateTripStats,1000);
  toast('检测到电池功率达到 50W，已自动开启行程记录');
}
function readTripTemp(d){const values=[d?.temperatures?.cell,d?.temperatures?.ambient,d?.temperatures?.mos,(d?.probes||[])[0],(d?.probes||[])[1]].map(finiteNum).filter(v=>v!==null);return values.length?Math.max(...values):null;}
function updateSpeedGauge(speedKmh){
  const needle=$('speedNeedle');
  if(!needle)return;
  const speed=Math.max(0,Math.min(60,Number(speedKmh)||0));
  // The needle is drawn vertically at rest. -90deg points to 0 km/h (left),
  // 0deg to 30 km/h (top), and +90deg to 60 km/h (right).
  const angle=-90+(speed/60)*180;
  needle.setAttribute('transform',`rotate(${angle.toFixed(2)} 160 183)`);
  needle.style.visibility='visible';
}
function updateTripBattery(d){
  if(!tripState?.active)return;
  const rem=finiteNum(d.remainingCapacityAh),soc=finiteNum(d.soc),current=Number(d.currentA)||0,cur=Math.abs(current),pow=Math.abs(Number(d.powerW)||0),temp=readTripTemp(d),sampleAt=Date.now();
  const voltage=finiteNum(d.voltage)??tripState.lastVoltage??60;
  const signedPowerW=voltage*current; // negative = pack discharge; positive = charging/regen input
  if(tripState.lastEnergyAt){
    const dt=Math.max(0,Math.min(30,(sampleAt-tripState.lastEnergyAt)/1000));
    const prevSigned=Number(tripState.lastSignedPowerW)||0;
    const dischargePrev=Math.max(0,-prevSigned),dischargeNow=Math.max(0,-signedPowerW);
    const regenPrev=Math.max(0,prevSigned),regenNow=Math.max(0,signedPowerW);
    tripState.energyWh+=(dischargePrev+dischargeNow)/2*dt/3600;
    tripState.regenWh+=(regenPrev+regenNow)/2*dt/3600;
  }
  tripState.lastEnergyAt=sampleAt;tripState.lastSignedPowerW=signedPowerW;tripState.lastVoltage=voltage;
  tripState.currentSoc=soc??tripState.currentSoc;tripState.currentRemainingAh=rem??tripState.currentRemainingAh;
  tripState.maxCurrent=Math.max(tripState.maxCurrent,cur);tripState.maxPower=Math.max(tripState.maxPower,pow);tripState.powerSum+=pow;tripState.powerCount++;
  const v=finiteNum(d.voltage),spread=finiteNum(d.spread);if(v!==null)tripState.minVoltage=tripState.minVoltage===null?v:Math.min(tripState.minVoltage,v);if(spread!==null)tripState.maxSpread=tripState.maxSpread===null?spread:Math.max(tripState.maxSpread,spread);
  if(temp!==null){tripState.maxTemp=tripState.maxTemp===null?temp:Math.max(tripState.maxTemp,temp);}
  $('tripPowerNow').textContent=Math.round(pow).toLocaleString('en-US');
  $('tripVoltage').textContent=`${Number(d.voltage).toFixed(1)} V`;
  $('tripCurrent').textContent=`${Number(d.currentA).toFixed(2)} A`;
  $('tripTemp').textContent=temp===null?'--°C':`${temp.toFixed(1)}°C`;
  $('tripSpread').textContent=d.spread==null?'--':String(d.spread);
  $('tripSoc').textContent=soc===null?'--%':`${soc.toFixed(1)}%`;
  $('tripRemainingAh').textContent=rem===null?'--':rem.toFixed(2);
  updateSpeedGauge(tripState.speedKmh||0);
  updateTripStats();
  // Stop is evaluated on every complete, CRC-validated BMS sample, not on GPS callbacks.
  if(pow<TRIP_STOP_POWER_W){
    log(`检测到 BMS 输出功率 ${pow.toFixed(2)}W，低于 1W，自动结束本次行程。`);
    finishTrip();
  }
}
function startBrowserLocation(){
  if(!navigator.geolocation){$('gpsStatus').textContent='GPS 不可用';$('tripGpsHint').textContent='当前环境不支持手机定位';return;}
  if(window._tripGeoWatch!==undefined)navigator.geolocation.clearWatch(window._tripGeoWatch);
  window._tripGeoWatch=navigator.geolocation.watchPosition(pos=>onTripLocation({latitude:pos.coords.latitude,longitude:pos.coords.longitude,accuracy:pos.coords.accuracy,hasSpeed:pos.coords.speed!==null,speedMps:pos.coords.speed,time:pos.timestamp,provider:'browser'}),err=>{$('gpsStatus').textContent='定位失败';$('tripGpsHint').textContent=err.message||'请允许定位权限';},{enableHighAccuracy:true,maximumAge:1000,timeout:15000});
}
function onTripLocation(loc){
  if(!tripState?.active)return;
  const lat=Number(loc.latitude),lon=Number(loc.longitude),accuracy=finiteNum(loc.accuracy),time=Number(loc.time)||Date.now();
  if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return;
  if(Date.now()-time>120000)return;
  if(accuracy!==null&&accuracy>100){$('gpsStatus').textContent='GPS 精度较低';$('tripGpsHint').textContent=`定位精度约 ${Math.round(accuracy)} 米，请移至室外`;return;}
  const point={lat,lon,time,accuracy:accuracy??0,speedKmh:0};
  const prev=tripState.lastPoint;
  if(prev){
    const dt=Math.max(.2,(time-prev.time)/1000),distance=haversine(prev,point);
    let derived=distance/dt*3.6;
    if(derived>150&&!loc.hasSpeed)return;
    const nativeSpeed=loc.hasSpeed&&finiteNum(loc.speedMps)!==null?Math.max(0,Number(loc.speedMps)*3.6):null;
    point.speedKmh=nativeSpeed!==null&&nativeSpeed<180?nativeSpeed:derived;
    if(distance>=2&&distance<1000){tripState.distanceM+=distance;}
    if(distance<2&&dt<4){point.speedKmh=prev.speedKmh||point.speedKmh;}
  }else{
    point.speedKmh=loc.hasSpeed&&finiteNum(loc.speedMps)!==null?Math.max(0,Number(loc.speedMps)*3.6):0;
  }
  tripState.speedKmh=Math.min(180,point.speedKmh||0);tripState.maxSpeed=Math.max(tripState.maxSpeed,tripState.speedKmh);
  if(!prev||haversine(prev,point)>=2||(time-prev.time)>5000){tripState.points.push(point);tripState.lastPoint=point;if(tripState.points.length>15000)tripState.points.shift();}
  $('gpsStatus').textContent='GPS 已定位';$('startGpsBtn').style.display='none';$('tripGpsHint').textContent=accuracy!==null?`GPS 已定位 · 精度约 ${Math.round(accuracy)} 米`:'GPS 已定位';
  $('tripMapStatus').textContent=`已记录 ${tripState.points.length} 个定位点`;
  $('tripSpeed').textContent=tripState.speedKmh.toFixed(1);
  $('tripTopSpeed').textContent=tripState.maxSpeed.toFixed(1);
  updateSpeedGauge(tripState.speedKmh);
  updateTripStats();refreshTripMap();
}
function updateTripStats(){
  if(!tripState?.active)return;
  const elapsed=Date.now()-tripState.startAt,distance=tripState.distanceM/1000,avg=elapsed>0?distance/(elapsed/3600000):0;
  $('tripDuration').textContent=fmtDuration(elapsed);$('tripDistance').textContent=distance.toFixed(2);$('tripAvgSpeed').textContent=avg.toFixed(1);
  const usedAh=tripState.startRemainingAh!==null&&tripState.currentRemainingAh!==null?Math.max(0,tripState.startRemainingAh-tripState.currentRemainingAh):0;
  let range=null;
  if(usedAh>0.02&&distance>0.05&&tripState.currentRemainingAh!==null){range=(distance/usedAh)*Math.max(0,tripState.currentRemainingAh);}
  else if(tripState.energyWh>2&&distance>0.05&&tripState.currentRemainingAh!==null){
    const remainingWh=Math.max(0,tripState.currentRemainingAh)*(tripState.lastVoltage||60);
    const whPerKm=tripState.energyWh/distance;
    if(whPerKm>0)range=remainingWh/whPerKm;
  }
  $('tripRange').textContent=range!==null&&Number.isFinite(range)?range.toFixed(0):'--';
}
function getAmapConfig(){
  try{return JSON.parse(localStorage.getItem('bydAmapConfig')||'{}')}catch(e){return {}}
}
function openMapSettings(){
  const cfg=getAmapConfig();$('amapKeyInput').value=cfg.key||'';$('amapSecurityInput').value=cfg.securityJsCode||'';$('mapConfigPanel').hidden=false;
}
function closeMapSettings(){$('mapConfigPanel').hidden=true;}
function destroyAmapState(state){if(state?.map){try{state.map.destroy();}catch(e){}}}
function saveMapSettings(){
  const key=$('amapKeyInput').value.trim(),securityJsCode=$('amapSecurityInput').value.trim();
  if(!key||!securityJsCode){toast('请同时填写高德 Key 和安全密钥');return;}
  localStorage.setItem('bydAmapConfig',JSON.stringify({key,securityJsCode}));
  closeMapSettings();
  if(!window.AMap){amapPromise=null;loadCurrentMap();toast(!$('tripView').hidden||!$('tripSummary').hidden?'地图配置已保存，正在加载高德地图':'地图配置已保存，进入骑行页面时会加载');}
  else {loadCurrentMap();toast('地图配置已保存，当前高德地图已刷新显示');}
}
function clearMapSettings(){
  localStorage.removeItem('bydAmapConfig');$('amapKeyInput').value='';$('amapSecurityInput').value='';
  closeMapSettings();
  destroyAmapState(liveMapState);liveMapState=null;
  destroyAmapState(summaryMapState);summaryMapState=null;
  amapPromise=null;
  const id=!$('tripView').hidden?'tripMap':(!$('tripSummary').hidden?'summaryMap':null);
  if(id){const root=$(id);root.innerHTML='<div id="'+id+'Empty" class="map-empty">请点击「地图设置」填写高德 Key 和安全密钥后加载中国地图</div>';}
  toast('已清除地图密钥');
}
function ensureAmapSdk(){
  const cfg=getAmapConfig();
  if(!cfg.key||!cfg.securityJsCode)return Promise.resolve(false);
  if(window.AMap)return Promise.resolve(true);
  if(amapPromise)return amapPromise;
  amapPromise=new Promise(resolve=>{
    window._AMapSecurityConfig={securityJsCode:cfg.securityJsCode};
    const script=document.createElement('script');
    let settled=false;
    const finish=ok=>{if(settled)return;settled=true;clearTimeout(timer);if(!ok)amapPromise=null;resolve(ok);};
    const timer=setTimeout(()=>finish(false),12000);
    script.src='https://webapi.amap.com/maps?v=2.0&key='+encodeURIComponent(cfg.key);
    script.async=true;
    script.onload=()=>finish(!!window.AMap);
    script.onerror=()=>finish(false);
    document.head.appendChild(script);
  });
  return amapPromise;
}
// Android GPS returns WGS-84. Keep raw coordinates for mileage/speed and convert
// display coordinates to GCJ-02 with AMap.convertFrom (max 40 points per call).
function fallbackGcj02(lon,lat){
  const out=lon<72.004||lon>137.8347||lat<0.8293||lat>55.8271;
  if(out)return [lon,lat];
  const PI=Math.PI,a=6378245.0,ee=0.00669342162296594323;
  const tLat=(x,y)=>{let v=-100+2*x+3*y+.2*y*y+.1*x*y+.2*Math.sqrt(Math.abs(x));v+=(20*Math.sin(6*x*PI)+20*Math.sin(2*x*PI))*2/3;v+=(20*Math.sin(y*PI)+40*Math.sin(y/3*PI))*2/3;v+=(160*Math.sin(y/12*PI)+320*Math.sin(y*PI/30))*2/3;return v;};
  const tLon=(x,y)=>{let v=300+x+2*y+.1*x*x+.1*x*y+.1*Math.sqrt(Math.abs(x));v+=(20*Math.sin(6*x*PI)+20*Math.sin(2*x*PI))*2/3;v+=(20*Math.sin(x*PI)+40*Math.sin(x/3*PI))*2/3;v+=(150*Math.sin(x/12*PI)+300*Math.sin(x/30*PI))*2/3;return v;};
  const x=lon-105,y=lat-35,rad=lat/180*PI,sin=Math.sin(rad),magic=1-ee*sin*sin,sqrtMagic=Math.sqrt(magic);
  let dLat=tLat(x,y)*180/((a*(1-ee))/(magic*sqrtMagic)*PI),dLon=tLon(x,y)*180/(a/sqrtMagic*Math.cos(rad)*PI);
  return [lon+dLon,lat+dLat];
}
function ensureAmapCoordinates(points){
  mapCoordQueue=mapCoordQueue.then(async()=>{
    const missing=points.filter(p=>!p.amapCoord);
    for(let i=0;i<missing.length;i+=40){
      const batch=missing.slice(i,i+40);
      await new Promise(resolve=>{
        let settled=false;
        const finish=()=>{if(settled)return;settled=true;clearTimeout(timer);resolve();};
        const useFallback=()=>batch.forEach(p=>{if(!p.amapCoord)p.amapCoord=fallbackGcj02(p.lon,p.lat);});
        const timer=setTimeout(()=>{useFallback();finish();},8000);
        try{
          AMap.convertFrom(batch.map(p=>[p.lon,p.lat]),'gps',(status,result)=>{
            if(settled)return;
            if(status==='complete'&&result&&result.info==='ok'&&Array.isArray(result.locations)&&result.locations.length===batch.length){
              batch.forEach((p,index)=>{const loc=result.locations[index];p.amapCoord=Array.isArray(loc)?[Number(loc[0]),Number(loc[1])]:[typeof loc.getLng==='function'?loc.getLng():Number(loc.lng),typeof loc.getLat==='function'?loc.getLat():Number(loc.lat)];if(!Number.isFinite(p.amapCoord[0])||!Number.isFinite(p.amapCoord[1]))p.amapCoord=fallbackGcj02(p.lon,p.lat);});
            }else useFallback();
            finish();
          });
        }catch(e){useFallback();finish();}
      });
    }
  }).catch(()=>{});
  return mapCoordQueue;
}
async function ensureMap(containerId,live){
  const ok=await ensureAmapSdk(),points=tripState?.points||[];
  if(!ok){
    const cfg=getAmapConfig();
    const msg=cfg.key?'高德地图加载失败：请检查 Web端 Key、安全密钥、域名白名单和网络连接':'请点击「地图设置」填写高德 Web端（JS API）Key 和安全密钥';
    drawFallbackRoute(containerId,points,msg);return null;
  }
  await ensureAmapCoordinates(points);
  const container=$(containerId);if(!container)return null;
  let state=live?liveMapState:summaryMapState;
  if(state&&state.containerId!==containerId)state=null;
  if(!state){
    const last=points.length?points[points.length-1]:null;
    const center=last?(last.amapCoord||fallbackGcj02(last.lon,last.lat)):[116.397428,39.90923];
    // When the map is first created before GPS has a fix, it starts at a broad
    // China view. The first real GPS point must zoom into street/city level.
    // Remember that first centering so subsequent live updates do not reset a
    // zoom level the user has chosen manually.
    const map=new AMap.Map(containerId,{viewMode:'2D',zoom:last?16:5,center,resizeEnable:true,animateEnable:false});
    const line=new AMap.Polyline({path:[],strokeColor:'#08a8d4',strokeWeight:6,strokeOpacity:.95,lineJoin:'round',lineCap:'round',zIndex:100});
    map.add(line);
    state={map,line,containerId,start:null,end:null,hasGpsCentered:!!last};
    if(live)liveMapState=state;else summaryMapState=state;
  }
  renderMapPoints(state,points,live);
  const empty=$(containerId+'Empty'); if(empty) empty.style.display='none';
  return state;
}
function makeAmapMarker(label,color,position,map){
  const el=document.createElement('div');el.textContent=label;el.style.cssText=`width:25px;height:25px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:${color};border:2px solid #fff;box-shadow:0 2px 8px #0006;color:#fff;font-size:11px;font-weight:900;display:flex;align-items:center;justify-content:center`;
  const inner=document.createElement('span');inner.textContent=label;inner.style.cssText='transform:rotate(45deg);';el.textContent='';el.appendChild(inner);
  const marker=new AMap.Marker({position,content:el,offset:new AMap.Pixel(-12,-25),anchor:'bottom',title:label,zIndex:120});map.add(marker);return marker;
}
function renderMapPoints(state,points,live){
  if(!state||!window.AMap)return;
  if(!points.length)return;
  const coords=points.map(p=>p.amapCoord||fallbackGcj02(p.lon,p.lat));
  state.line.setPath(coords);
  const first=coords[0],last=coords[coords.length-1];
  if(!state.start)state.start=makeAmapMarker('起','#12b981',first,state.map);else state.start.setPosition(first);
  if(!state.end)state.end=makeAmapMarker(live?'行':'终','#e84d5b',last,state.map);else{state.end.setPosition(last);state.end.setContent((()=>{const e=document.createElement('div');e.textContent=live?'行':'终';e.style.cssText='width:25px;height:25px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:#e84d5b;border:2px solid #fff;color:white;font-size:11px;font-weight:900;display:flex;align-items:center;justify-content:center';return e;})());}
  if(live){
    if(!state.hasGpsCentered){
      // The map was created while waiting for GPS and still had the default
      // province-level zoom. Apply a one-time local zoom on the first fix.
      state.map.setZoomAndCenter(16,last);
      state.hasGpsCentered=true;
    }else{
      // Follow the latest point without changing the user's selected zoom.
      state.map.setCenter(last,true);
    }
  }
  else if(coords.length>1){state.map.setFitView([state.line,state.start,state.end],false,[30,30,30,30]);}
  else state.map.setZoomAndCenter(16,last);
  const empty=$(state.containerId+'Empty');if(empty)empty.style.display='none';
}
function loadCurrentMap(){
  if(!$('tripView').hidden)ensureMap('tripMap',true).then(state=>{if(state)renderMapPoints(state,tripState?.points||[],true);});
  else if(!$('tripSummary').hidden)ensureMap('summaryMap',false).then(state=>{if(state)renderMapPoints(state,tripState?.points||[],false);});
}
async function refreshTripMap(){
  if(!tripState?.points?.length)return;
  if(liveMapState&&window.AMap){await ensureAmapCoordinates(tripState.points);renderMapPoints(liveMapState,tripState.points,true);}
  else {const state=await ensureMap('tripMap',true);if(state)renderMapPoints(state,tripState.points,true);}
}
function drawFallbackRoute(containerId,points,message){
  const root=$(containerId);if(!root)return;
  if(!points.length){root.innerHTML='<div id="'+containerId+'Empty" class="map-empty">'+(message||'等待 GPS 轨迹')+'</div>';return;}
  const meanLat=points.reduce((a,p)=>a+p.lat,0)/points.length,cos=Math.cos(meanLat*Math.PI/180)||1;
  const xs=points.map(p=>p.lon*cos),ys=points.map(p=>p.lat),minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys),dx=maxX-minX||.0001,dy=maxY-minY||.0001;
  const project=p=>[25+(p.lon*cos-minX)/dx*350,245-(p.lat-minY)/dy*210];
  const path=points.map((p,i)=>{const q=project(p);return `${i?'L':'M'} ${q[0].toFixed(1)} ${q[1].toFixed(1)}`;}).join(' '),a=project(points[0]),b=project(points[points.length-1]);
  root.innerHTML=`<svg class="route-fallback" viewBox="0 0 400 270" preserveAspectRatio="none"><path d="${path}" fill="none" stroke="#08b9e4" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${a[0]}" cy="${a[1]}" r="8" fill="#0cbb81" stroke="white" stroke-width="3"/><circle cx="${b[0]}" cy="${b[1]}" r="8" fill="#eb4d5a" stroke="white" stroke-width="3"/><text x="200" y="22" text-anchor="middle" fill="#b8c9d8" font-size="12">${message||'高德地图加载失败 · 当前仅显示轨迹示意'}</text></svg>`;
}
const TRIP_HISTORY_KEY='bydRideHistory_v1';
function readTripHistory(){try{const v=JSON.parse(localStorage.getItem(TRIP_HISTORY_KEY)||'[]');return Array.isArray(v)?v:[];}catch(e){return [];}}
function compactTripRoute(points,maxPoints=300){
  const source=Array.isArray(points)?points:[];if(source.length<=maxPoints)return source.map(p=>[Number(p.lat),Number(p.lon),Number(p.time)||0]);
  const out=[],step=(source.length-1)/(maxPoints-1);for(let i=0;i<maxPoints;i++){const p=source[Math.round(i*step)];out.push([Number(p.lat),Number(p.lon),Number(p.time)||0]);}return out;
}
function recordFromTrip(t){
  const duration=Math.max(0,(t.endAt||Date.now())-t.startAt),distance=t.distanceM/1000,avg=duration>0?distance/(duration/3600000):0;
  const socUsed=t.startSoc!==null&&t.currentSoc!==null?Math.max(0,t.startSoc-t.currentSoc):null;
  const ahUsed=t.startRemainingAh!==null&&t.currentRemainingAh!==null?Math.max(0,t.startRemainingAh-t.currentRemainingAh):null;
  return {id:String(t.startAt),deviceName:'FD042884',startAt:t.startAt,endAt:t.endAt||Date.now(),durationMs:duration,distanceM:Number(t.distanceM)||0,maxSpeed:Number(t.maxSpeed)||0,avgSpeed:avg,maxCurrent:Number(t.maxCurrent)||0,maxPower:Number(t.maxPower)||0,avgPower:t.powerCount?Number(t.powerSum)/t.powerCount:0,regenWh:Number(t.regenWh)||0,energyWh:Number(t.energyWh)||0,socUsed,ahUsed,efficiency:ahUsed!==null&&ahUsed>.01?distance/ahUsed:null,minVoltage:finiteNum(t.minVoltage),maxSpread:finiteNum(t.maxSpread),startTemp:finiteNum(t.startTemp),maxTemp:finiteNum(t.maxTemp),points:compactTripRoute(t.points)};
}
function persistTripRecord(t){
  if(!t||t.savedToHistory)return null;
  const rec=recordFromTrip(t),all=readTripHistory().filter(x=>String(x.id)!==rec.id);all.unshift(rec);
  // Keep the newest rides. Route samples are capped so local WebView storage remains bounded.
  while(all.length>100)all.pop();
  // Compact routes from older app versions too, so the 100-record target remains practical in WebView storage.
  for(const item of all){if(Array.isArray(item.points)&&item.points.length>300){const src=item.points,packed=[],step=(src.length-1)/299;for(let i=0;i<300;i++)packed.push(src[Math.round(i*step)]);item.points=packed;}}
  while(true){try{localStorage.setItem(TRIP_HISTORY_KEY,JSON.stringify(all));t.savedToHistory=true;log(`骑行记录已保存到本机（${all.length} 条）`);return rec.id;}catch(e){if(all.length>1){all.pop();continue;}if(rec.points?.length){rec.points=compactTripRoute(t.points,180);try{localStorage.setItem(TRIP_HISTORY_KEY,JSON.stringify([rec]));t.savedToHistory=true;return rec.id;}catch(_){}}toast('本机存储空间不足，未能保存完整骑行记录');return null;}}
}
function formatTripStamp(ms){const d=new Date(Number(ms)||Date.now());return `${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;}
function fmtRecordDuration(ms){const s=Math.max(0,Math.floor((Number(ms)||0)/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),ss=s%60;return h?`${h}h ${m}m`:m?`${m}m ${ss}s`:`${ss}s`;}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function showTripHistory(){
  if(tripState?.active){toast('当前仍在骑行，请先结束本次行程再查看历史记录');return;}
  document.querySelector('.app').style.display='none';$('tripView').hidden=true;$('tripSummary').hidden=true;$('tripHistory').hidden=false;viewingSavedTrip=false;
  renderTripHistory();if(native())window.BmsNative.setTripScreenOn(false);
}
function renderTripHistory(){
  const list=$('tripHistoryList'),records=readTripHistory();$('historyCount').textContent=`${records.length} 次行程`;
  if(!records.length){list.innerHTML='<div class="history-empty">还没有骑行记录。完成第一次行程后，记录会自动保存在本机。</div>';return;}
  list.innerHTML=records.map(r=>{
    const routeStart=formatTripStamp(r.startAt),routeEnd=formatTripStamp(r.endAt),duration=fmtRecordDuration(r.durationMs),distance=(Number(r.distanceM||0)/1000).toFixed(2);
    const n=(v,d=1)=>v===null||v===undefined||!Number.isFinite(Number(v))?'--':Number(v).toFixed(d);
    return `<article class="history-card"><div class="history-card-top"><div class="history-date">🚲 ${routeStart} ～ ${routeEnd}</div><div class="history-duration">${duration}</div></div><div class="history-device">${esc(r.deviceName||'FD042884')}</div><div class="history-primary"><div class="distance"><label>骑行里程</label><strong>${distance}<small> km</small></strong></div><div><label>最快速度</label><strong>${n(r.maxSpeed)}</strong></div><div><label>平均速度</label><strong>${n(r.avgSpeed)}</strong></div></div><div class="history-section-title">能耗与电气状态</div><div class="history-extra"><div><label>SOC 消耗</label><strong>${n(r.socUsed)}<small>%</small></strong></div><div><label>容量消耗</label><strong>${n(r.ahUsed,3)}<small> Ah</small></strong></div><div><label>平均功率</label><strong>${n(r.avgPower,0)}<small> W</small></strong></div><div><label>最大功率</label><strong>${n(r.maxPower,0)}<small> W</small></strong></div><div><label>最大电流</label><strong>${n(r.maxCurrent)}<small> A</small></strong></div><div><label>最低总压</label><strong>${n(r.minVoltage)}<small> V</small></strong></div><div><label>压差峰值</label><strong>${r.maxSpread==null?'--':Math.round(Number(r.maxSpread))}<small> mV</small></strong></div><div><label>温升幅度</label><strong>${r.startTemp==null||r.maxTemp==null?'--':(Number(r.maxTemp)-Number(r.startTemp)>=0?'+':'')+(Number(r.maxTemp)-Number(r.startTemp)).toFixed(1)}<small> °C</small></strong></div><div><label>动能回收</label><strong>${r.regenWh==null?'--':Number(r.regenWh).toFixed(2)}<small> Wh</small></strong></div></div><div class="history-efficiency">⚡ 续航效率： ${n(r.efficiency,2)} km/Ah</div><div class="history-actions"><button type="button" data-open-trip="${esc(r.id)}">📍 轨迹详情</button><button class="delete" type="button" data-delete-trip="${esc(r.id)}">删除记录</button></div></article>`;
  }).join('');
}
function openSavedTrip(id){
  if(tripState?.active){toast('当前骑行尚未结束');return;}
  const r=readTripHistory().find(x=>String(x.id)===String(id));if(!r)return;
  tripState={active:false,startAt:r.startAt,endAt:r.endAt,distanceM:Number(r.distanceM)||0,maxSpeed:Number(r.maxSpeed)||0,speedKmh:0,startSoc:r.socUsed===null?null:Number(r.socUsed),currentSoc:r.socUsed===null?null:0,startRemainingAh:r.ahUsed===null?null:Number(r.ahUsed),currentRemainingAh:r.ahUsed===null?null:0,maxCurrent:Number(r.maxCurrent)||0,maxPower:Number(r.maxPower)||0,powerSum:0,powerCount:0,avgPower:finiteNum(r.avgPower),regenWh:finiteNum(r.regenWh),energyWh:finiteNum(r.energyWh)||0,minVoltage:r.minVoltage,maxSpread:r.maxSpread,startTemp:r.startTemp,maxTemp:r.maxTemp,points:(r.points||[]).map(p=>({lat:Number(p[0]),lon:Number(p[1]),time:Number(p[2])||0})),savedToHistory:true};
  viewingSavedTrip=true;renderTripSummary(tripState,true);
}
$('tripHistoryList').addEventListener('click',e=>{
  const open=e.target.closest('[data-open-trip]'),del=e.target.closest('[data-delete-trip]');
  if(open){openSavedTrip(open.getAttribute('data-open-trip'));return;}
  if(del){const id=del.getAttribute('data-delete-trip');if(!confirm('确定删除这条骑行记录吗？'))return;localStorage.setItem(TRIP_HISTORY_KEY,JSON.stringify(readTripHistory().filter(r=>String(r.id)!==String(id))));renderTripHistory();}
});
function finishTrip(){
  if(!tripState?.active)return;
  tripState.active=false;tripState.endAt=Date.now();clearInterval(tripClockTimer);tripClockTimer=null;
  if(native()){window.BmsNative.setRideActive(false);window.BmsNative.stopLocationTracking();window.BmsNative.setTripScreenOn(false);window.BmsNative.keepBatteryConnected();log('行程已结束，保持电池 FD042884 蓝牙连接与持续读取，不主动断开。');}else if(window._tripGeoWatch!==undefined){navigator.geolocation.clearWatch(window._tripGeoWatch);window._tripGeoWatch=undefined;}
  tripArmed=false;
  persistTripRecord(tripState);
  renderTripSummary(tripState,false);
}
function renderTripSummary(t,isArchive=false){
  if(native())window.BmsNative.setTripScreenOn(false);
  $('tripView').hidden=true;$('tripHistory').hidden=true;$('tripSummary').hidden=false;document.querySelector('.app').style.display='none';
  $('summaryBack').textContent='‹';$('summaryDashboard').textContent=isArchive?'返回记录':'返回电池监控';$('summaryClose').textContent='返回主页';
  const duration=Math.max(0,(t.endAt||Date.now())-t.startAt),dist=t.distanceM/1000,avg=duration>0?dist/(duration/3600000):0;
  const socUsed=t.startSoc!==null&&t.currentSoc!==null?Math.max(0,t.startSoc-t.currentSoc):null;
  const ahUsed=t.startRemainingAh!==null&&t.currentRemainingAh!==null?Math.max(0,t.startRemainingAh-t.currentRemainingAh):null;
  const efficiency=ahUsed!==null&&ahUsed>.01?dist/ahUsed:null;
  const vals={sumDuration:fmtDuration(duration),sumDistance:dist.toFixed(2),sumAvgSpeed:avg.toFixed(1),sumMaxSpeed:t.maxSpeed.toFixed(1),sumMaxCurrent:t.maxCurrent.toFixed(1),sumMaxPower:Math.round(t.maxPower).toLocaleString('en-US'),sumSocUsed:socUsed===null?'--':socUsed.toFixed(1),sumAhUsed:ahUsed===null?'--':ahUsed.toFixed(2),sumEfficiency:efficiency===null?'--':efficiency.toFixed(2),sumTempRise:t.startTemp===null||t.maxTemp===null?'--':(t.maxTemp-t.startTemp).toFixed(1),sumAvgPower:(t.powerCount?Number(t.powerSum)/t.powerCount:finiteNum(t.avgPower))===null?'--':Math.round(t.powerCount?Number(t.powerSum)/t.powerCount:Number(t.avgPower)||0),sumRegen:finiteNum(t.regenWh)===null?'--':Number(t.regenWh).toFixed(2)};
  for(const [id,value] of Object.entries(vals))$(id).textContent=value;
  $('summaryCaption').textContent=`行程轨迹 · ${t.points.length} 个定位点 · 高德地图（GCJ-02）`;
  destroyAmapState(summaryMapState); summaryMapState=null;
  $('summaryMap').innerHTML='<div id="summaryMapEmpty" class="map-empty">正在生成行程轨迹…</div>';
  const empty=$('summaryMapEmpty');if(empty)empty.style.display=t.points.length?'none':'flex';
  if(t.points.length){ensureMap('summaryMap',false).then(state=>{if(state){renderMapPoints(state,t.points,false);}else drawFallbackRoute('summaryMap',t.points);});}
  else {$('summaryMap').innerHTML='<div id="summaryMapEmpty" class="map-empty">未获取到 GPS 轨迹，请检查手机定位权限和室外信号</div>';}
}
// Precision-style 0–60 km/h dial: minor ticks every 1 km/h, numbered marks every 10.
(function drawSpeedTicks(){
  const root=$('speedTicks'); if(!root)return;
  const ns='http://www.w3.org/2000/svg';
  for(let i=0;i<=60;i++){
    const angle=(180+i*180/60)*Math.PI/180;
    const major=i%10===0, medium=i%5===0;
    const r1=major?117:(medium?121:125), r2=major?139:(medium?134:130);
    const x1=160+Math.cos(angle)*r1, y1=183+Math.sin(angle)*r1;
    const x2=160+Math.cos(angle)*r2, y2=183+Math.sin(angle)*r2;
    const line=document.createElementNS(ns,'line');
    line.setAttribute('x1',x1.toFixed(2));line.setAttribute('y1',y1.toFixed(2));
    line.setAttribute('x2',x2.toFixed(2));line.setAttribute('y2',y2.toFixed(2));
    line.setAttribute('class',major?'speed-tick speed-tick-major':(medium?'speed-tick speed-tick-medium':'speed-tick'));
    line.setAttribute('opacity',major?'1':(medium?'.82':'.48'));
    root.appendChild(line);
    if(major){
      const label=document.createElementNS(ns,'text');
      const lr=153,lx=160+Math.cos(angle)*lr,ly=183+Math.sin(angle)*lr;
      label.setAttribute('x',lx.toFixed(2));label.setAttribute('y',(ly+4).toFixed(2));
      label.setAttribute('text-anchor','middle');label.setAttribute('class','speed-tick-label');
      label.textContent=String(i);root.appendChild(label);
    }
  }
})();
$('tripBack').addEventListener('click',showDashboard);
$('resumeTripBtn').addEventListener('click',showTripPage);
$('startGpsBtn').addEventListener('click',()=>{if(native())window.BmsNative.startLocationTracking();else startBrowserLocation();});
$('endTripBtn').addEventListener('click',finishTrip);
function returnFromSummary(){if(viewingSavedTrip){$('tripSummary').hidden=true;showTripHistory();}else showDashboard();}
$('summaryBack').addEventListener('click',returnFromSummary);
$('summaryDashboard').addEventListener('click',returnFromSummary);
$('summaryClose').addEventListener('click',showDashboard);
$('rideHistoryBtn').addEventListener('click',showTripHistory);
$('historyBack').addEventListener('click',showDashboard);
$('mapConfigMainBtn').addEventListener('click',openMapSettings);$('mapConfigBtn').addEventListener('click',openMapSettings);$('summaryMapConfigBtn').addEventListener('click',openMapSettings);$('mapConfigClose').addEventListener('click',closeMapSettings);$('mapConfigSave').addEventListener('click',saveMapSettings);$('mapConfigClear').addEventListener('click',clearMapSettings);

function bytesToHex(a){return Array.from(a,b=>b.toString(16).padStart(2,'0')).join('').toUpperCase()}
function hexToBytes(h){if(h.length%2)throw new Error('HEX 长度不是偶数');const a=new Uint8Array(h.length/2);for(let i=0;i<a.length;i++)a[i]=parseInt(h.slice(i*2,i*2+2),16);return a}
function crc16(a){let crc=0xFFFF;for(const v of a){crc^=v;for(let i=0;i<8;i++)crc=(crc&1)?((crc>>>1)^0xA001):(crc>>>1)}return crc&0xFFFF}
function crcText(a){const c=crc16(a);return ((c&255).toString(16).padStart(2,'0')+((c>>>8)&255).toString(16).padStart(2,'0')).toUpperCase()}
function makeCommand(addr,count){const body=new Uint8Array([0xF4,0x03,(addr>>8)&255,addr&255,count&255]);return bytesToHex(body)+crcText(body)}
function u16(b,o){return b[o]|(b[o+1]<<8)}function s16(b,o){const n=u16(b,o);return n&0x8000?n-0x10000:n}
function decodeData(b){
  if(b.length!==124)throw new Error(`寄存器长度不对：${b.length}`);
  const voltageRaw=u16(b,22),socRaw=u16(b,48),sohRaw=u16(b,50),sohPercent=sohRaw>0&&sohRaw<=1000?sohRaw/10:null,remRaw=u16(b,52),ratedRaw=u16(b,56),cycle=u16(b,60),series=(b[62]<<8)|b[63];
  const soc=socRaw/10,voltage=voltageRaw/100,rated=ratedRaw>0? ratedRaw/1000:FALLBACK_AH;
  const remValid=remRaw>0&&(ratedRaw===0||remRaw<=ratedRaw*1.2),remaining=remValid?remRaw/1000:rated*soc/100;
  
  const t=o=>{const n=u16(b,o);return n===65535||n>1000?null:n/10};
  const temperatures={cell:t(28),ambient:t(30),mos:t(32)};
  const probes=[t(116),t(118),t(120),t(122)];
  // Static and loaded samples cross-check this signed word: 0x0000 -> 0.00 A; 0xFFEF -> -0.17 A.
  const currentRawUnsigned=u16(b,26),currentRawSigned=s16(b,26),currentA=currentRawSigned/100,powerW=Math.abs(voltage*currentA);
  const cells=[];let min=Infinity,max=-Infinity,sum=0,valid=0;
  for(let i=0;i<20;i++){
    const raw=u16(b,68+i*2),good=raw>=2000&&raw<=4500&&raw!==65535,mv=good?raw:null;
    cells.push({index:i+1,mv,raw,offset:68+i*2});
    if(good){valid++;min=Math.min(min,raw);max=Math.max(max,raw);sum+=raw;}
  }
  const all=valid===20,sumV=all?sum/1000:null,delta=all?Math.abs(sumV-voltage):null,words=[];
  for(let o=0;o<124;o+=2)words.push({offset:o,hex:bytesToHex(b.slice(o,o+2)),u16:u16(b,o),s16:s16(b,o)});
  return {voltage,voltageRaw,soc,socRaw,remainingCapacityAh:remaining,ratedCapacityAh:rated,capacitySource:remValid?'bms':'soc_estimate',sohPercent,sohRaw,sohRegisterOffset:50,remainingCapacityRaw:remRaw,ratedCapacityRaw:ratedRaw,cycleCount:cycle,seriesCount:series,temperatures,probes,currentRegisterOffset:26,currentScaleA:0.01,currentRawCandidate:currentRawSigned,currentRawUnsigned,currentRawSigned,currentA,powerW,auxWord24Unsigned:u16(b,24),auxWord24Signed:s16(b,24),cells,min:all?min:null,max:all?max:null,spread:all?max-min:null,sum:sumV,delta,sumMatches:all&&delta<=.05,allPresent:all,validCellCount:valid,registerWords:words,rawHex:bytesToHex(b)};
}
function parseFrame(buffer,count,address){
  const start=buffer.indexOf('F403');
  if(start<0){if(buffer.length>16)throw new Error(`响应中未找到 F403 帧头：${buffer.slice(0,16)}`);return null;}
  if(start>0)buffer=buffer.slice(start);
  if(buffer.length<6)return null;
  let payloadStart=6,gotCount=parseInt(buffer.slice(4,6),16),layout='字节数响应';
  if(gotCount!==count){
    if(buffer.length<10)return null;
    const echoedAddress=parseInt(buffer.slice(4,8),16),echoedCount=parseInt(buffer.slice(8,10),16);
    if(echoedAddress===address&&echoedCount===count){payloadStart=10;layout='地址+字节数回显响应';}
    else throw new Error(`响应长度字段不匹配：收到 ${buffer.slice(0,10)}，当前请求地址 0x${address.toString(16).toUpperCase()}、期望 ${count} 字节。已中止本轮，避免错配。`);
  }
  const total=payloadStart+count*2+4;
  if(buffer.length<total)return null;
  const frame=buffer.slice(0,total),received=frame.slice(-4).toUpperCase(),expected=crcText(hexToBytes(frame.slice(0,-4)));
  if(received!==expected)throw new Error(`CRC 校验失败：收到 ${received}，计算 ${expected}`);
  return {frame,payload:hexToBytes(frame.slice(payloadStart,-4)),leftover:buffer.slice(total),crc:received,layout};
}
function onWebNotification(ev){
  const dv=ev.target.value,chunk=new Uint8Array(dv.buffer,dv.byteOffset,dv.byteLength);
  const rawHex=bytesToHex(chunk);let ascii='';for(const b of chunk)ascii+=(b>=32&&b<=126)?String.fromCharCode(b):'.';
  const rec={time:new Date().toISOString(),byteLength:chunk.length,hex:rawHex,ascii};notifyRecords.push(rec);if(notifyRecords.length>250)notifyRecords.shift();
  const part=ascii.toUpperCase().replace(/[^0-9A-F]/g,'');
  if(!pending){orphanNotifications.push(rec);if(orphanNotifications.length>100)orphanNotifications.shift();log(`收到非请求期间通知（已保留原始数据）：${part.slice(0,24)}`);return;}
  pending.buffer+=part;
  try{const parsed=parseFrame(pending.buffer,pending.count,pending.address);if(parsed){const p=pending;pending=null;clearTimeout(p.timer);if(parsed.leftover){orphanNotifications.push({time:new Date().toISOString(),ascii:parsed.leftover,reason:'同一通知中的额外数据'});log(`响应帧后存在额外数据 ${parsed.leftover.length} 字符，已隔离保存。`);}p.resolve(parsed);}}
  catch(e){const p=pending;pending=null;if(p){clearTimeout(p.timer);p.reject(e)}}
}
function requestBlock(addr,count){return new Promise(async(resolve,reject)=>{
  if(!tx||!rx){reject(new Error('蓝牙读写特征值未准备好'));return;}
  if(pending){reject(new Error('上一条请求仍未结束，已阻止并发读取'));return;}
  const p={address:addr,count,buffer:'',resolve,reject,timer:null};pending=p;
  p.timer=setTimeout(()=>{if(pending===p){pending=null;reject(new Error(`读取 0x${addr.toString(16).toUpperCase()} 超时；已停止本轮，不会把迟到响应分配给下一条请求`));}},8000);
  try{const command=makeCommand(addr,count);log(`TX ${command}（0x${addr.toString(16).toUpperCase()} / ${count}字节）`);const data=new TextEncoder().encode(command);if(tx.writeValueWithoutResponse)await tx.writeValueWithoutResponse(data);else await tx.writeValue(data);}
  catch(e){if(pending===p){pending=null;clearTimeout(p.timer)}reject(new Error(`发送读取命令失败：${e.message}`))}
})}
async function readAllWeb(){
  if(readBusy||!connected||!rx||!tx)return;readBusy=true;
  const raw=new Uint8Array(124),blocks=[{addr:0x1000,count:60,offset:0},{addr:0x103C,count:60,offset:60},{addr:0x1078,count:4,offset:120}],frames=[];
  try{
    for(let i=0;i<blocks.length;i++){
      const b=blocks[i],r=await requestBlock(b.addr,b.count);raw.set(r.payload,b.offset);
      frames.push({time:new Date().toISOString(),address:'0x'+b.addr.toString(16).toUpperCase(),request:makeCommand(b.addr,b.count),response:r.frame,payloadHex:bytesToHex(r.payload),crc:r.crc,crcValid:true,layout:r.layout});
      log(`RX ${b.count} 字节，CRC ${r.crc} 校验通过`);
      // 只在数据块之间留出静默窗口；最后一块完成后不再多等一轮。
      if(i<blocks.length-1)await new Promise(r=>setTimeout(r,650));
    }
    const d=decodeData(raw);lastRawHex=bytesToHex(raw);lastFrames=frames;displayData(d);
    readHistory.push({time:new Date().toISOString(),voltage:d.voltage,soc:d.soc,currentA:d.currentA,powerW:d.powerW,currentRawCandidate:d.currentRawCandidate,currentRawUnsigned:d.currentRawUnsigned,currentRawSigned:d.currentRawSigned,auxWord24Signed:d.auxWord24Signed,cycleCount:d.cycleCount,sohPercent:d.sohPercent,sohRaw:d.sohRaw,temperatures:d.temperatures,probes:d.probes,spread:d.spread,rawHex:d.rawHex});if(readHistory.length>180)readHistory.shift();
  }catch(e){log(`本轮读取已中止：${e.message}`);toast(`读取未完成：${e.message}`);await new Promise(r=>setTimeout(r,1200));}
  finally{readBusy=false;}
}
function startWebPolling(){clearTimeout(webPollTimer);const loop=async()=>{if(!connected||native())return;await readAllWeb();if(connected)webPollTimer=setTimeout(loop,REFRESH_MS)};loop()}
async function connectWeb(){if(!navigator.bluetooth){toast('当前浏览器不支持 Web Bluetooth。请用安卓 Chrome，通过 HTTPS 网页打开。');log('浏览器不支持 Web Bluetooth。');return}try{$('scanBtn').disabled=true;$('topStatus').textContent='正在选择设备';const dev=await navigator.bluetooth.requestDevice({filters:[{namePrefix:'FD'}],optionalServices:[SERVICE]});webDevice=dev;webDevice.addEventListener('gattserverdisconnected',()=>{connected=false;clearTimeout(webPollTimer);tx=null;rx=null;webServer=null;status(false,'连接已断开','蓝牙连接结束',webDevice?.name||'FD 设备');log('设备蓝牙连接已断开。')});status(false,'正在连接','正在连接 BLE…',dev.name||'FD 设备');webServer=await dev.gatt.connect();const svc=await webServer.getPrimaryService(SERVICE);tx=await svc.getCharacteristic(WRITE);rx=await svc.getCharacteristic(NOTIFY);rx.addEventListener('characteristicvaluechanged',onWebNotification);await rx.startNotifications();status(true,'已连接','已订阅通知',dev.name||'FD 设备');$('deviceList').classList.remove('show');toast('连接成功，开始读取 BMS');log(`连接成功：${dev.name||'FD 设备'}；通知已订阅。`);startWebPolling()}catch(e){$('scanBtn').disabled=false;status(false,'未连接','', 'FD042884');log(`蓝牙连接失败：${e.message}`);toast(`连接失败：${e.message}`)}}
function disconnectWeb(){clearTimeout(webPollTimer);if(pending){clearTimeout(pending.timer);pending.reject(new Error('用户断开连接'));pending=null}try{if(webDevice?.gatt?.connected)webDevice.gatt.disconnect()}catch(e){}connected=false;tx=null;rx=null;status(false,'未连接','','FD042884');log('已手动断开。')}
function addDevices(list){for(const d of list){if(!nativeDevices.some(x=>x.address===d.address))nativeDevices.push(d)}const root=$('deviceItems');root.innerHTML='';for(const d of nativeDevices){const b=document.createElement('button');b.className='device-item';const left=document.createElement('span');const n=document.createElement('strong');n.textContent=d.name||'FD 蓝牙设备';const a=document.createElement('small');a.textContent=d.address||'';left.append(n,a);const r=document.createElement('em');r.textContent='连接 →';b.append(left,r);b.addEventListener('click',()=>{if(native())window.BmsNative.connect(d.address,d.name||'FD 设备')});root.append(b)}$('deviceList').classList.toggle('show',nativeDevices.length>0)}
window.handleAndroidBack=()=>{
  if(!$('mapConfigPanel').hidden){closeMapSettings();return true;}
  if(document.activeElement&&/^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName)){document.activeElement.blur();return true;}
  const openDetails=[...document.querySelectorAll('details[open]')].pop();if(openDetails){openDetails.open=false;return true;}
  if(!$('tripSummary').hidden){returnFromSummary();return true;}
  if(!$('tripHistory').hidden){showDashboard();return true;}
  if(!$('tripView').hidden){showDashboard();toast(tripState?.active?'行程仍在后台记录，可点击“返回行程”继续查看':'已返回电池监控');return true;}
  // Dashboard is the root screen: consume Back rather than unexpectedly exiting the app.
  toast('已经在电池监控主页');return true;
};
let reconnectPullStartY=null;
window.addEventListener('touchstart',e=>{if(!native()||connected||$('reconnectHint').hidden||e.touches.length!==1||window.scrollY>2)return;reconnectPullStartY=e.touches[0].clientY;},{passive:true});
window.addEventListener('touchend',e=>{if(reconnectPullStartY===null)return;const dy=e.changedTouches?.[0]?.clientY-reconnectPullStartY;const start=reconnectPullStartY;reconnectPullStartY=null;if(Number.isFinite(dy)&&dy>85&&start<150&&window.scrollY<=2&&$('reconnectHint').hidden===false){window.BmsNative.resumeAutoReconnect();toast('已手动恢复重连，将再尝试 3 次');}},{passive:true});
window.onNativeMessage=m=>{if(!m)return;switch(m.type){case'scanStarted':nativeDevices=[];$('deviceItems').innerHTML='';$('deviceList').classList.add('show');$('topStatus').textContent='正在扫描';log('正在扫描 FD 系列蓝牙设备…');break;case'deviceFound':if(m.device)addDevices([m.device]);break;case'scanFinished':toast(nativeDevices.length?`扫描完成，发现 ${nativeDevices.length} 台设备`:'未发现 FD 设备');break;case'status':status(m.connected,m.title,m.caption,m.name);if(m.connected){toast('蓝牙连接成功');$('deviceList').classList.remove('show')}break;case'data':displayData(m.data);lastRawHex=m.rawHex||m.data.rawHex||lastRawHex;if(Array.isArray(m.responseFrames))lastFrames=m.responseFrames;if(Array.isArray(m.bleNotifications))notifyRecords=m.bleNotifications;if(Array.isArray(m.orphanNotifications))orphanNotifications=m.orphanNotifications;readHistory.push({time:new Date().toISOString(),voltage:m.data.voltage,soc:m.data.soc,sohPercent:m.data.sohPercent,sohRaw:m.data.sohRaw,currentA:m.data.currentA,powerW:m.data.powerW,currentRawCandidate:m.data.currentRawCandidate,currentRawUnsigned:m.data.currentRawUnsigned,currentRawSigned:m.data.currentRawSigned,cycleCount:m.data.cycleCount,temperatures:m.data.temperatures,probes:m.data.probes,spread:m.data.spread,rawHex:lastRawHex});if(readHistory.length>180)readHistory.shift();break;case'log':log(m.message);break;case'error':log(`错误：${m.message}`);toast(m.message);break;case'location':onTripLocation(m);break;case'locationStatus':$('gpsStatus').textContent=m.tracking?'GPS 定位中':(m.message?.includes('权限')?'需要定位权限':'定位不可用');$('tripGpsHint').textContent=m.message||'';$('tripMapStatus').textContent=m.tracking?'已启动，等待坐标':(m.message||'定位已停止');if(!m.tracking&&tripState?.active){$('startGpsBtn').style.display='inline-block';if(m.message)toast(m.message);}break;case'exported':toast(m.message||'诊断记录已保存');log(m.message||'诊断记录已保存');break;}};
$('scanBtn').addEventListener('click',()=>{if(native())window.BmsNative.startScan();else connectWeb()});$('readBtn').addEventListener('click',()=>{if(native())window.BmsNative.readAll();else readAllWeb()});$('disconnectBtn').addEventListener('click',()=>{if(native())window.BmsNative.disconnect();else disconnectWeb()});
$('backgroundMonitorBtn').addEventListener('click',()=>{if(native())window.BmsNative.requestBackgroundMonitorAccess();else toast('请在 Android App 内开启后台监控权限。');});
$('exportBtn').addEventListener('click',()=>{const report={app:'BYD BMS Monitor 0.24',time:new Date().toISOString(),deviceName:webDevice?.name||$('topDevice').textContent,connection:connected?'connected':'disconnected',protocol:{service:SERVICE,write:WRITE,notify:NOTIFY,requestFormat:'ASCII HEX F403 + address + byteCount + CRC16-Modbus',registerStart:'0x1000',registerBytes:124,chunkBytes:[60,60,4],refreshGapMs:REFRESH_MS,betweenBlockQuietWindowMs:650,sohRegisterOffset:50,sohScale:0.1,sohMethod:'BMS data word at byte offset 50, uint16 little-endian, 0.1% per unit'},latestData:lastData,lastRawRegisterHex:lastRawHex,responseFrames:lastFrames,bleNotifications:notifyRecords,orphanNotifications,readHistory,logs};if(native())window.BmsNative.exportDiagnostic(JSON.stringify(report));else{const blob=new Blob([JSON.stringify(report,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`BYD-BMS-0.24-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1500);toast('诊断 JSON 已导出，发送这个文件即可')}});
setInterval(()=>{if(lastReadAt){const sec=Math.max(0,Math.floor((Date.now()-lastReadAt)/1000));$('topAge').textContent=sec<2?'刚刚更新':`${sec}秒前`}},1000);
// Empty state only: never populate this page with another app's screenshot/sample readings.
status(false,'未连接','','FD042884');
log(navigator.bluetooth?'0.24 网页蓝牙持续监控模式已就绪。请在安卓 Chrome 的 HTTPS 页面中点击“扫描并连接”。':'BYD BMS Monitor 0.24 已就绪。请在 Android App 中连接 FD042884。');
})();
