package com.byd.bmsmonitor;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
    private static final String WRITE_UUID = "6e400002-b5a3-f393-e0a9-e50e24dcca9e";
    private static final String NOTIFY_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";
    private static final String CCCD_UUID = "00002902-0000-1000-8000-00805f9b34fb";
    private static final int REQUEST_PERMISSIONS = 7101;
    private static final int CREATE_DIAGNOSTIC = 7102;
    private static final int SCAN_DURATION_MS = 12000;
    private static final int RESPONSE_TIMEOUT_MS = 8000;
    private static final int REFRESH_INTERVAL_MS = 3000;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView webView;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic writeCharacteristic;
    private BluetoothGattCharacteristic notifyCharacteristic;
    private ScanCallback scanCallback;
    private final ArrayList<JSONObject> foundDevices = new ArrayList<>();
    private final JSONArray notificationHistory = new JSONArray();
    private final JSONArray orphanHistory = new JSONArray();
    private final JSONArray latestFrames = new JSONArray();
    private final byte[] fullPayload = new byte[124];
    private final int[] blockAddresses = new int[]{0x1000, 0x103C, 0x1078};
    private final int[] blockCounts = new int[]{60, 60, 4};
    private final int[] blockOffsets = new int[]{0, 60, 120};
    private int blockIndex = 0;
    private boolean connected = false;
    private boolean ready = false;
    private boolean readBusy = false;
    private boolean autoRefresh = false;
    private boolean scanning = false;
    private String deviceName = "FD042884";
    private String rxBuffer = "";
    private int expectedAddress = 0;
    private int expectedCount = 0;
    private boolean waitingResponse = false;
    private Runnable responseTimeout;
    private Runnable pollRunnable;
    private JSONArray currentFrames;
    private JSONArray currentNotifications;
    private JSONArray currentOrphans;
    private String pendingExportJson;
    private Runnable actionAfterPermission;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 20, 29));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 20, 29));
        getWindow().getDecorView().setSystemUiVisibility(0);

        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if (manager != null) bluetoothAdapter = manager.getAdapter();

        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 20, 29));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setDatabaseEnabled(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new BmsBridge(), "BmsNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasBlePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void runWithPermissions(Runnable action) {
        if (hasBlePermissions()) {
            action.run();
            return;
        }
        actionAfterPermission = action;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMISSIONS);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            Runnable action = actionAfterPermission;
            actionAfterPermission = null;
            if (granted && action != null) action.run();
            else emitError("需要蓝牙扫描和连接权限才能读取电池数据。");
        }
    }

    private void startScanInternal() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            emitError("请先打开安卓手机蓝牙，再重新扫描。");
            return;
        }
        if (scanning) stopScanInternal();
        scanner = bluetoothAdapter.getBluetoothLeScanner();
        if (scanner == null) {
            emitError("当前手机无法启动 BLE 扫描。");
            return;
        }
        foundDevices.clear();
        scanning = true;
        emit(typeMessage("scanStarted"));
        scanCallback = new ScanCallback() {
            @Override public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                if (device == null) return;
                String name = null;
                try { name = device.getName(); } catch (SecurityException ignored) { }
                if (name == null || !name.toUpperCase(Locale.ROOT).startsWith("FD")) return;
                String address = device.getAddress();
                for (JSONObject item : foundDevices) {
                    if (address.equals(item.optString("address"))) return;
                }
                JSONObject entry = new JSONObject();
                try { entry.put("name", name); entry.put("address", address); } catch (JSONException ignored) { }
                foundDevices.add(entry);
                JSONObject msg = typeMessage("deviceFound");
                try { msg.put("device", entry); } catch (JSONException ignored) { }
                emit(msg);
            }
            @Override public void onScanFailed(int errorCode) {
                scanning = false;
                emitError("蓝牙扫描失败，错误代码 " + errorCode);
            }
        };
        try {
            ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(null, settings, scanCallback);
            main.postDelayed(() -> {
                if (scanning) {
                    stopScanInternal();
                    emit(typeMessage("scanFinished"));
                }
            }, SCAN_DURATION_MS);
        } catch (SecurityException e) {
            scanning = false;
            emitError("没有蓝牙扫描权限：" + e.getMessage());
        }
    }

    private void stopScanInternal() {
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null && scanCallback != null) scanner.stopScan(scanCallback); }
        catch (SecurityException ignored) { }
    }

    private void connectInternal(String address, String name) {
        if (address == null || address.trim().isEmpty()) { emitError("设备地址为空。"); return; }
        stopScanInternal();
        disconnectInternal(false);
        try {
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
            deviceName = (name == null || name.isEmpty()) ? "FD 设备" : name;
            emitStatus(false, "正在连接", "正在连接 BLE…", deviceName);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            } else {
                gatt = device.connectGatt(this, false, gattCallback);
            }
        } catch (Exception e) {
            emitError("连接失败：" + e.getMessage());
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                emitError("GATT 连接状态异常，错误代码 " + status);
                disconnectInternal(true);
                return;
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connected = true;
                emitLog("BLE 已连接，正在发现 Nordic UART 服务…");
                try { g.discoverServices(); }
                catch (SecurityException e) { emitError("缺少蓝牙连接权限。"); }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                disconnectInternal(true);
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) { emitError("发现 BLE 服务失败：" + status); return; }
            android.bluetooth.BluetoothGattService service = g.getService(UUID.fromString(SERVICE_UUID));
            if (service == null) { emitError("未找到 Nordic UART 服务。"); disconnectInternal(true); return; }
            writeCharacteristic = service.getCharacteristic(UUID.fromString(WRITE_UUID));
            notifyCharacteristic = service.getCharacteristic(UUID.fromString(NOTIFY_UUID));
            if (writeCharacteristic == null || notifyCharacteristic == null) {
                emitError("未找到 BLE 写入或通知特征值。"); disconnectInternal(true); return;
            }
            try {
                boolean ok = g.setCharacteristicNotification(notifyCharacteristic, true);
                BluetoothGattDescriptor descriptor = notifyCharacteristic.getDescriptor(UUID.fromString(CCCD_UUID));
                if (!ok || descriptor == null) { emitError("无法开启 BLE 通知。"); return; }
                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                g.writeDescriptor(descriptor);
            } catch (SecurityException e) { emitError("开启 BLE 通知时缺少权限。"); }
        }

        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int status) {
            if (CCCD_UUID.equalsIgnoreCase(descriptor.getUuid().toString()) && status == BluetoothGatt.GATT_SUCCESS) {
                ready = true;
                connected = true;
                emitStatus(true, "已连接", "BLE 通知已订阅", deviceName);
                emitLog("Nordic UART 服务就绪，开始读取 20 串电池数据。");
                main.postDelayed(() -> {
                    if (ready && !readBusy) beginReadAll();
                }, 350);
            } else {
                emitError("BLE 通知订阅失败：" + status);
            }
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            byte[] value = characteristic.getValue();
            if (value != null) main.post(() -> handleNotification(value.clone()));
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
            if (value != null) main.post(() -> handleNotification(value.clone()));
        }

        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic characteristic, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) emitError("BLE 写入请求失败：" + status);
        }
    };

    private void handleNotification(byte[] bytes) {
        String ascii = new String(bytes, StandardCharsets.US_ASCII);
        StringBuilder hex = new StringBuilder();
        for (byte b : bytes) hex.append(String.format(Locale.ROOT, "%02X", b & 0xff));
        JSONObject record = new JSONObject();
        try {
            record.put("time", nowIso());
            record.put("byteLength", bytes.length);
            record.put("hex", hex.toString());
            record.put("ascii", ascii);
        } catch (JSONException ignored) { }
        synchronized (notificationHistory) {
            notificationHistory.put(record);
            trimArray(notificationHistory, 250);
        }

        if (!waitingResponse) {
            synchronized (orphanHistory) { orphanHistory.put(record); trimArray(orphanHistory, 100); }
            emitLog("收到非请求期间 BLE 通知，已保留原始帧。");
            return;
        }
        String cleaned = ascii.toUpperCase(Locale.ROOT).replaceAll("[^0-9A-F]", "");
        rxBuffer += cleaned;
        try {
            ParsedFrame frame = tryParseFrame(rxBuffer, expectedCount, expectedAddress);
            if (frame == null) return;
            waitingResponse = false;
            if (responseTimeout != null) main.removeCallbacks(responseTimeout);
            rxBuffer = "";
            onBlockReceived(frame);
        } catch (Exception e) {
            cancelPending();
            abortRead("响应解析失败：" + e.getMessage());
        }
    }

    private void beginReadAll() {
        if (!ready || readBusy) return;
        readBusy = true;
        blockIndex = 0;
        currentFrames = new JSONArray();
        currentNotifications = new JSONArray();
        currentOrphans = new JSONArray();
        for (int i = 0; i < fullPayload.length; i++) fullPayload[i] = 0;
        readNextBlock();
    }

    private void readNextBlock() {
        if (!ready || !readBusy) return;
        if (blockIndex >= blockAddresses.length) {
            try {
                JSONObject data = decodePayload(fullPayload);
                JSONObject message = typeMessage("data");
                message.put("data", data);
                message.put("rawHex", bytesToHex(fullPayload));
                message.put("responseFrames", currentFrames);
                message.put("bleNotifications", snapshot(notificationHistory));
                message.put("orphanNotifications", snapshot(orphanHistory));
                emit(message);
                emitLog("完整读取成功：总压 " + data.getDouble("voltage") + "V，SOC " + data.getDouble("soc") + "%，电流 " + data.getDouble("currentA") + "A。");
            } catch (Exception e) {
                emitError("解析寄存器失败：" + e.getMessage());
            }
            readBusy = false;
            if (autoRefresh && ready) {
                if (pollRunnable != null) main.removeCallbacks(pollRunnable);
                pollRunnable = this::beginReadAll;
                main.postDelayed(pollRunnable, REFRESH_INTERVAL_MS);
            }
            return;
        }
        expectedAddress = blockAddresses[blockIndex];
        expectedCount = blockCounts[blockIndex];
        rxBuffer = "";
        waitingResponse = true;
        final int addressForTimeout = expectedAddress;
        responseTimeout = () -> {
            if (waitingResponse && expectedAddress == addressForTimeout) {
                waitingResponse = false;
                rxBuffer = "";
                abortRead("读取 0x" + Integer.toHexString(addressForTimeout).toUpperCase(Locale.ROOT) + " 超时；已停止本轮，避免迟到数据错配。");
            }
        };
        main.postDelayed(responseTimeout, RESPONSE_TIMEOUT_MS);
        String command = makeCommand(expectedAddress, expectedCount);
        emitLog("TX " + command + "（0x" + Integer.toHexString(expectedAddress).toUpperCase(Locale.ROOT) + " / " + expectedCount + " 字节）");
        try {
            byte[] ascii = command.getBytes(StandardCharsets.US_ASCII);
            if (Build.VERSION.SDK_INT >= 33) {
                int result = gatt.writeCharacteristic(writeCharacteristic, ascii, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                if (result != BluetoothGatt.GATT_SUCCESS) abortRead("发送读取命令失败，状态码 " + result);
            } else {
                writeCharacteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                writeCharacteristic.setValue(ascii);
                boolean ok = gatt.writeCharacteristic(writeCharacteristic);
                if (!ok) abortRead("发送读取命令未能进入 BLE 队列。");
            }
        } catch (Exception e) {
            abortRead("发送读取命令失败：" + e.getMessage());
        }
    }

    private void onBlockReceived(ParsedFrame frame) {
        int offset = blockOffsets[blockIndex];
        System.arraycopy(frame.payload, 0, fullPayload, offset, frame.payload.length);
        JSONObject item = new JSONObject();
        try {
            item.put("time", nowIso());
            item.put("address", String.format(Locale.ROOT, "0x%04X", expectedAddress));
            item.put("request", makeCommand(expectedAddress, expectedCount));
            item.put("response", frame.frame);
            item.put("payloadHex", bytesToHex(frame.payload));
            item.put("crc", frame.crc);
            item.put("crcValid", true);
            item.put("layout", frame.layout);
            currentFrames.put(item);
        } catch (JSONException ignored) { }
        emitLog("RX " + expectedCount + " 字节，CRC " + frame.crc + " 校验通过。");
        blockIndex++;
        main.postDelayed(this::readNextBlock, 650);
    }

    private void abortRead(String message) {
        cancelPending();
        readBusy = false;
        emitLog("本轮读取已中止：" + message);
        if (autoRefresh && ready) {
            if (pollRunnable != null) main.removeCallbacks(pollRunnable);
            pollRunnable = this::beginReadAll;
            main.postDelayed(pollRunnable, 2500);
        }
    }

    private void cancelPending() {
        waitingResponse = false;
        rxBuffer = "";
        if (responseTimeout != null) main.removeCallbacks(responseTimeout);
    }

    private ParsedFrame tryParseFrame(String buffer, int count, int address) throws Exception {
        int start = buffer.indexOf("F403");
        if (start < 0) {
            if (buffer.length() > 16) throw new Exception("响应中未找到 F403 帧头：" + buffer.substring(0, 16));
            return null;
        }
        String b = buffer.substring(start);
        if (b.length() < 6) return null;
        int payloadStart = 6;
        int countField = parseHexInt(b.substring(4, 6));
        String layout = "字节数响应";
        if (countField != count) {
            if (b.length() < 10) return null;
            int echoedAddress = parseHexInt(b.substring(4, 8));
            int echoedCount = parseHexInt(b.substring(8, 10));
            if (echoedAddress == address && echoedCount == count) {
                payloadStart = 10;
                layout = "地址+字节数回显响应";
            } else {
                throw new Exception("响应头不匹配：" + b.substring(0, 10));
            }
        }
        int totalChars = payloadStart + count * 2 + 4;
        if (b.length() < totalChars) return null;
        String frame = b.substring(0, totalChars);
        String receivedCrc = frame.substring(frame.length() - 4).toUpperCase(Locale.ROOT);
        byte[] crcBytes = hexToBytes(frame.substring(0, frame.length() - 4));
        String expectedCrc = crcText(crcBytes);
        if (!receivedCrc.equalsIgnoreCase(expectedCrc)) throw new Exception("CRC 错误：收到 " + receivedCrc + "，应为 " + expectedCrc);
        byte[] payload = hexToBytes(frame.substring(payloadStart, frame.length() - 4));
        return new ParsedFrame(frame, payload, receivedCrc, layout);
    }

    private JSONObject decodePayload(byte[] b) throws JSONException {
        if (b.length != 124) throw new JSONException("数据长度不是 124 字节");
        int voltageRaw = u16(b, 22);
        int socRaw = u16(b, 48);
        int remRaw = u16(b, 52);
        int ratedRaw = u16(b, 56);
        int cycle = u16(b, 60);
        int series = ((b[62] & 0xff) << 8) | (b[63] & 0xff);
        double soc = socRaw / 10.0;
        double voltage = voltageRaw / 100.0;
        double rated = ratedRaw > 0 ? ratedRaw / 1000.0 : 24.0;
        boolean remValid = remRaw > 0 && (ratedRaw == 0 || remRaw <= ratedRaw * 1.2);
        double remaining = remValid ? remRaw / 1000.0 : rated * soc / 100.0;

        JSONObject temperatures = new JSONObject();
        putNullable(temperatures, "cell", readTemp(b, 28));
        putNullable(temperatures, "ambient", readTemp(b, 30));
        putNullable(temperatures, "mos", readTemp(b, 32));
        JSONArray probes = new JSONArray();
        for (int offset : new int[]{116, 118, 120, 122}) {
            Double t = readTemp(b, offset);
            probes.put(t == null ? JSONObject.NULL : t);
        }
        int currentUnsigned = u16(b, 26);
        int currentSigned = (short) currentUnsigned;
        double currentA = currentSigned / 100.0;
        double powerW = Math.abs(voltage * currentA);

        JSONArray cells = new JSONArray();
        int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE, sum = 0, valid = 0;
        for (int i = 0; i < 20; i++) {
            int offset = 68 + i * 2;
            int raw = u16(b, offset);
            boolean good = raw >= 2000 && raw <= 4500 && raw != 65535;
            JSONObject c = new JSONObject();
            c.put("index", i + 1);
            c.put("mv", good ? raw : JSONObject.NULL);
            c.put("raw", raw);
            c.put("offset", offset);
            cells.put(c);
            if (good) { valid++; min = Math.min(min, raw); max = Math.max(max, raw); sum += raw; }
        }
        boolean all = valid == 20;
        double cellSum = all ? sum / 1000.0 : Double.NaN;
        double delta = all ? Math.abs(cellSum - voltage) : Double.NaN;

        JSONArray words = new JSONArray();
        for (int offset = 0; offset < 124; offset += 2) {
            JSONObject w = new JSONObject();
            w.put("offset", offset);
            w.put("hex", String.format(Locale.ROOT, "%02X%02X", b[offset] & 0xff, b[offset + 1] & 0xff));
            w.put("u16", u16(b, offset));
            w.put("s16", (short) u16(b, offset));
            words.put(w);
        }

        JSONObject out = new JSONObject();
        out.put("voltage", voltage); out.put("voltageRaw", voltageRaw);
        out.put("soc", soc); out.put("socRaw", socRaw);
        out.put("remainingCapacityAh", remaining); out.put("ratedCapacityAh", rated);
        out.put("capacitySource", remValid ? "bms" : "soc_estimate");
        out.put("remainingCapacityRaw", remRaw); out.put("ratedCapacityRaw", ratedRaw);
        out.put("cycleCount", cycle); out.put("seriesCount", series);
        out.put("temperatures", temperatures); out.put("probes", probes);
        out.put("currentRegisterOffset", 26); out.put("currentScaleA", 0.01);
        out.put("currentRawCandidate", currentSigned); out.put("currentRawUnsigned", currentUnsigned);
        out.put("currentRawSigned", currentSigned); out.put("currentA", currentA); out.put("powerW", powerW);
        out.put("auxWord24Unsigned", u16(b, 24)); out.put("auxWord24Signed", (short) u16(b, 24));
        out.put("cells", cells);
        out.put("min", all ? min : JSONObject.NULL); out.put("max", all ? max : JSONObject.NULL);
        out.put("spread", all ? max - min : JSONObject.NULL);
        out.put("sum", all ? cellSum : JSONObject.NULL); out.put("delta", all ? delta : JSONObject.NULL);
        out.put("sumMatches", all && delta <= 0.05); out.put("allPresent", all); out.put("validCellCount", valid);
        out.put("registerWords", words); out.put("rawHex", bytesToHex(b));
        return out;
    }

    private Double readTemp(byte[] b, int offset) {
        int raw = u16(b, offset);
        if (raw == 65535 || raw > 1000) return null;
        return raw / 10.0;
    }

    private void disconnectInternal(boolean notifyUi) {
        autoRefresh = false;
        ready = false;
        connected = false;
        readBusy = false;
        cancelPending();
        if (pollRunnable != null) main.removeCallbacks(pollRunnable);
        BluetoothGatt old = gatt;
        gatt = null;
        writeCharacteristic = null;
        notifyCharacteristic = null;
        if (old != null) {
            try { old.disconnect(); } catch (Exception ignored) { }
            try { old.close(); } catch (Exception ignored) { }
        }
        if (notifyUi) emitStatus(false, "未连接", "蓝牙连接已断开", deviceName);
    }

    private class BmsBridge {
        @JavascriptInterface public void startScan() {
            main.post(() -> runWithPermissions(() -> startScanInternal()));
        }
        @JavascriptInterface public void connect(String address, String name) {
            main.post(() -> runWithPermissions(() -> connectInternal(address, name)));
        }
        @JavascriptInterface public void readAll() { main.post(() -> beginReadAll()); }
        @JavascriptInterface public void disconnect() { main.post(() -> disconnectInternal(true)); }
        @JavascriptInterface public void setAutoRefresh(boolean enabled) {
            main.post(() -> {
                autoRefresh = enabled;
                if (!enabled && pollRunnable != null) main.removeCallbacks(pollRunnable);
                if (enabled && ready && !readBusy && pollRunnable == null) {
                    pollRunnable = MainActivity.this::beginReadAll;
                    main.postDelayed(pollRunnable, REFRESH_INTERVAL_MS);
                }
            });
        }
        @JavascriptInterface public void exportDiagnostic(String json) {
            main.post(() -> beginExport(json));
        }
    }

    private void beginExport(String json) {
        pendingExportJson = json;
        String filename = "BYD-BMS-0.11-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) + ".json";
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(intent, CREATE_DIAGNOSTIC);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_DIAGNOSTIC && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
                if (stream == null) throw new IllegalStateException("无法打开保存位置");
                stream.write((pendingExportJson == null ? "{}" : pendingExportJson).getBytes(StandardCharsets.UTF_8));
                stream.flush();
                emit(new JSONObject().put("type", "exported").put("message", "诊断 JSON 已保存到你选择的位置。"));
            } catch (Exception e) {
                emitError("保存诊断文件失败：" + e.getMessage());
            }
        }
        pendingExportJson = null;
    }

    private void emitStatus(boolean on, String title, String caption, String name) {
        JSONObject obj = typeMessage("status");
        try { obj.put("connected", on); obj.put("title", title); obj.put("caption", caption); obj.put("name", name); }
        catch (JSONException ignored) { }
        emit(obj);
    }
    private void emitLog(String message) {
        JSONObject obj = typeMessage("log");
        try { obj.put("message", message); } catch (JSONException ignored) { }
        emit(obj);
    }
    private void emitError(String message) {
        JSONObject obj = typeMessage("error");
        try { obj.put("message", message); } catch (JSONException ignored) { }
        emit(obj);
    }
    private JSONObject typeMessage(String type) {
        JSONObject obj = new JSONObject();
        try { obj.put("type", type); } catch (JSONException ignored) { }
        return obj;
    }
    private void emit(JSONObject message) {
        if (webView == null) return;
        String json = message.toString();
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript("window.onNativeMessage && window.onNativeMessage(" + json + ");", null);
        });
    }

    private static int u16(byte[] b, int offset) { return (b[offset] & 0xff) | ((b[offset + 1] & 0xff) << 8); }
    private static String bytesToHex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02X", b & 0xff));
        return out.toString();
    }
    private static byte[] hexToBytes(String hex) {
        if ((hex.length() & 1) != 0) throw new IllegalArgumentException("HEX 长度不是偶数");
        byte[] out = new byte[hex.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
        return out;
    }
    private static int parseHexInt(String value) { return Integer.parseInt(value, 16); }
    private static int crc16Modbus(byte[] bytes) {
        int crc = 0xffff;
        for (byte value : bytes) {
            crc ^= value & 0xff;
            for (int i = 0; i < 8; i++) crc = ((crc & 1) != 0) ? ((crc >>> 1) ^ 0xa001) : (crc >>> 1);
        }
        return crc & 0xffff;
    }
    private static String crcText(byte[] bytes) {
        int crc = crc16Modbus(bytes);
        return String.format(Locale.ROOT, "%02X%02X", crc & 0xff, (crc >>> 8) & 0xff);
    }
    private static String makeCommand(int address, int count) {
        byte[] header = new byte[]{(byte) 0xf4, 0x03, (byte) ((address >>> 8) & 0xff), (byte) (address & 0xff), (byte) count};
        return bytesToHex(header) + crcText(header);
    }
    private static void putNullable(JSONObject obj, String key, Double value) throws JSONException {
        obj.put(key, value == null ? JSONObject.NULL : value);
    }
    private static String nowIso() { return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(new Date()); }
    private static JSONArray snapshot(JSONArray source) {
        JSONArray copy = new JSONArray();
        synchronized (source) { for (int i = 0; i < source.length(); i++) copy.put(source.opt(i)); }
        return copy;
    }
    private static void trimArray(JSONArray array, int max) {
        // JSON arrays are append-only in Android's org.json API; keep the newest bounded tail by rebuilding.
        if (array.length() <= max) return;
        JSONArray keep = new JSONArray();
        for (int i = array.length() - max; i < array.length(); i++) keep.put(array.opt(i));
        for (int i = array.length() - 1; i >= 0; i--) array.remove(i);
        for (int i = 0; i < keep.length(); i++) array.put(keep.opt(i));
    }

    private static class ParsedFrame {
        final String frame;
        final byte[] payload;
        final String crc;
        final String layout;
        ParsedFrame(String frame, byte[] payload, String crc, String layout) {
            this.frame = frame; this.payload = payload; this.crc = crc; this.layout = layout;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        autoRefresh = false;
        stopScanInternal();
        disconnectInternal(false);
        if (webView != null) { webView.removeJavascriptInterface("BmsNative"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
