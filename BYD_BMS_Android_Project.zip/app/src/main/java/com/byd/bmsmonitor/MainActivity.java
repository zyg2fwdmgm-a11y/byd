package com.byd.bmsmonitor;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.GeolocationPermissions;
import android.content.SharedPreferences;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
    private static final String WRITE_UUID = "6e400002-b5a3-f393-e0a9-e50e24dcca9e";
    private static final String NOTIFY_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";
    private static final String CCCD_UUID = "00002902-0000-1000-8000-00805f9b34fb";
    private static final int REQUEST_PERMISSIONS = 7101;
    private static final int CREATE_DIAGNOSTIC = 7102;
    private static final int REQUEST_LOCATION_PERMISSION = 7103;
    private static final int REQUEST_NOTIFICATION_PERMISSION = 7104;
    private static final int REQUEST_OVERLAY_PERMISSION = 7105;
    private static final int SCAN_DURATION_MS = 12000;
    private static final int RESPONSE_TIMEOUT_MS = 8000;
    private static final int REFRESH_INTERVAL_MS = 250;
    private static final int MAX_RECONNECT_ATTEMPTS = 3;
    private static final String DEVICE_PREFS = "byd_bms_device";
    private static final String PREF_DEVICE_ADDRESS = "remembered_device_address";

    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView webView;
    private WebViewAssetLoader webViewAssetLoader;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private boolean locationTracking = false;
    private boolean tripScreenOn = false;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic writeCharacteristic;
    private BluetoothGattCharacteristic notifyCharacteristic;
    private ScanCallback scanCallback;
    private final ArrayList<JSONObject> foundDevices = new ArrayList<>();
    private final JSONArray notificationHistory = new JSONArray();
    private final JSONArray orphanHistory = new JSONArray();
    private final JSONArray latestFrames = new JSONArray();
    private final byte[] fullPayload = new byte[124];
    private final int[] blockAddresses = new int[]{0x1000, 0x103C, 0x1078};
    private final int[] blockCounts = new int[]{60, 60, 4};
    private final int[] blockOffsets = new int[]{0, 60, 120};
    private int blockIndex = 0;
    private boolean connected = false;
    private boolean ready = false;
    private boolean readBusy = false;
    private boolean autoRefresh = false;
    private boolean scanning = false;
    private String deviceName = "FD042884";
    private String rxBuffer = "";
    private int expectedAddress = 0;
    private int expectedCount = 0;
    private boolean waitingResponse = false;
    private Runnable responseTimeout;
    private Runnable pollRunnable;
    private JSONArray currentFrames;
    private JSONArray currentNotifications;
    private JSONArray currentOrphans;
    private String pendingExportJson;
    private Runnable actionAfterPermission;
    private String rememberedAddress;
    private boolean autoReconnectEnabled = false;
    private boolean monitorServiceStarted = false;
    private boolean overlaySettingsOpened = false;
    private int reconnectAttempt = 0;
    private Runnable reconnectRunnable;
    private boolean locationPermissionPending = false;
    private OnBackInvokedCallback backInvokedCallback;
    private final ArrayList<Runnable> locationGrantedCallbacks = new ArrayList<>();
    private final ArrayList<Runnable> locationDeniedCallbacks = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 33) {
            backInvokedCallback = this::dispatchBackToWeb;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, backInvokedCallback);
        }
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 20, 29));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 20, 29));
        getWindow().getDecorView().setSystemUiVisibility(0);

        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if (manager != null) bluetoothAdapter = manager.getAdapter();
        SharedPreferences devicePrefs = getSharedPreferences(DEVICE_PREFS, MODE_PRIVATE);
        rememberedAddress = devicePrefs.getString(PREF_DEVICE_ADDRESS, null);
        autoReconnectEnabled = rememberedAddress != null && !rememberedAddress.trim().isEmpty();
        monitorServiceStarted = BmsMonitorService.isRunning();

        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 20, 29));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.getSettings().setUserAgentString(android.webkit.WebSettings.getDefaultUserAgent(this) + " BYD-BMS-Monitor/0.24");
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setDatabaseEnabled(false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                Uri uri = Uri.parse(origin == null ? "" : origin);
                if (!"https".equalsIgnoreCase(uri.getScheme()) || !"appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())) {
                    callback.invoke(origin, false, false);
                    return;
                }
                withLocationPermission(
                        () -> callback.invoke(origin, true, false),
                        () -> callback.invoke(origin, false, false)
                );
            }
        });
        webViewAssetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return webViewAssetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // Only the packaged local page may be a top-level document. AMap scripts/tiles
                // remain normal HTTPS subresources; unrelated pages cannot inherit BmsNative.
                return !"https".equalsIgnoreCase(uri.getScheme())
                        || !"appassets.androidplatform.net".equalsIgnoreCase(uri.getHost());
            }
        });
        webView.addJavascriptInterface(new BmsBridge(), "BmsNative");
        setContentView(webView);
        // Use a secure local HTTPS origin so Web map SDKs can validate their web-domain key.
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        if (autoReconnectEnabled) {
            main.postDelayed(() -> scheduleReconnect(1200L), 1800L);
        }
    }

    private boolean hasBlePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void runWithPermissions(Runnable action) {
        if (hasBlePermissions()) {
            action.run();
            return;
        }
        actionAfterPermission = action;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMISSIONS);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            Runnable action = actionAfterPermission;
            actionAfterPermission = null;
            if (granted && action != null) action.run();
            else emitError("需要蓝牙扫描和连接权限才能读取电池数据。");
        } else if (requestCode == REQUEST_LOCATION_PERMISSION) {
            locationPermissionPending = false;
            boolean granted = hasAnyLocationPermission();
            ArrayList<Runnable> callbacks = new ArrayList<>(granted ? locationGrantedCallbacks : locationDeniedCallbacks);
            locationGrantedCallbacks.clear();
            locationDeniedCallbacks.clear();
            for (Runnable callback : callbacks) {
                try { callback.run(); } catch (Exception ignored) { }
            }
            if (!granted) emitLocationStatus(false, "没有获得定位权限。请在系统设置中允许 BYD BMS 使用位置信息，并开启精确位置。", false);
        } else if (requestCode == REQUEST_NOTIFICATION_PERMISSION) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (!granted) Toast.makeText(this, "通知权限未开启，后台服务仍可运行，但通知栏状态条可能不可见。", Toast.LENGTH_LONG).show();
            openOverlayPermissionSettings();
        }
    }

    private void requestBackgroundMonitorAccess() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATION_PERMISSION);
            return;
        }
        openOverlayPermissionSettings();
    }

    private void openOverlayPermissionSettings() {
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            try {
                overlaySettingsOpened = true;
                Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
            } catch (Exception e) {
                Toast.makeText(this, "无法打开悬浮窗权限设置，请到系统设置中允许 BYD BMS 显示在其他应用上层。", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "后台悬浮窗权限已允许。切出应用时会显示实时状态小窗。", Toast.LENGTH_LONG).show();
        }
    }

    private void startScanInternal() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            emitError("请先打开安卓手机蓝牙，再重新扫描。");
            return;
        }
        if (scanning) stopScanInternal();
        scanner = bluetoothAdapter.getBluetoothLeScanner();
        if (scanner == null) {
            emitError("当前手机无法启动 BLE 扫描。");
            return;
        }
        foundDevices.clear();
        scanning = true;
        emit(typeMessage("scanStarted"));
        scanCallback = new ScanCallback() {
            @Override public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                if (device == null) return;
                String name = null;
                try { name = device.getName(); } catch (SecurityException ignored) { }
                if (name == null || !name.toUpperCase(Locale.ROOT).startsWith("FD")) return;
                String address = device.getAddress();
                for (JSONObject item : foundDevices) {
                    if (address.equals(item.optString("address"))) return;
                }
                JSONObject entry = new JSONObject();
                try { entry.put("name", name); entry.put("address", address); } catch (JSONException ignored) { }
                foundDevices.add(entry);
                JSONObject msg = typeMessage("deviceFound");
                try { msg.put("device", entry); } catch (JSONException ignored) { }
                emit(msg);
            }
            @Override public void onScanFailed(int errorCode) {
                scanning = false;
                emitError("蓝牙扫描失败，错误代码 " + errorCode);
            }
        };
        try {
            ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(null, settings, scanCallback);
            main.postDelayed(() -> {
                if (scanning) {
                    stopScanInternal();
                    emit(typeMessage("scanFinished"));
                }
            }, SCAN_DURATION_MS);
        } catch (SecurityException e) {
            scanning = false;
            emitError("没有蓝牙扫描权限：" + e.getMessage());
        }
    }

    private void stopScanInternal() {
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null && scanCallback != null) scanner.stopScan(scanCallback); }
        catch (SecurityException ignored) { }
    }

    private void connectInternal(String address, String name) {
        connectInternal(address, name, true);
    }

    private void connectInternal(String address, String name, boolean rememberDevice) {
        if (address == null || address.trim().isEmpty()) { emitError("设备地址为空。"); return; }
        cancelReconnect();
        stopScanInternal();
        if (rememberDevice) {
            rememberedAddress = address;
            autoReconnectEnabled = true;
            reconnectAttempt = 0;
            getSharedPreferences(DEVICE_PREFS, MODE_PRIVATE).edit().putString(PREF_DEVICE_ADDRESS, address).apply();
        }
        disconnectInternal(false);
        try {
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
            deviceName = (name == null || name.isEmpty()) ? "FD042884" : name;
            emitStatus(false, "正在连接", rememberDevice ? "正在连接并记住这块电池…" : "正在自动重连 FD042884…", deviceName);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            } else {
                gatt = device.connectGatt(this, false, gattCallback);
            }
            if (gatt == null) throw new IllegalStateException("系统未能创建 GATT 连接");
        } catch (Exception e) {
            emitError("连接失败：" + e.getMessage());
            if (autoReconnectEnabled) scheduleReconnect(1800L);
        }
    }

    private void cancelReconnect() {
        if (reconnectRunnable != null) main.removeCallbacks(reconnectRunnable);
        reconnectRunnable = null;
    }

    private void scheduleReconnect(long requestedDelayMs) {
        if (!autoReconnectEnabled || rememberedAddress == null || rememberedAddress.trim().isEmpty()
                || connected || gatt != null || scanning || isFinishing() || reconnectRunnable != null) return;
        if (reconnectAttempt >= MAX_RECONNECT_ATTEMPTS) {
            emitStatus(false, "重连暂停", "已连续自动连接失败 3 次。请回到主页顶部向下拉动，手动刷新后继续重连。", deviceName);
            emitLog("自动重连已连续失败 3 次，暂停重试；等待用户在主页下拉刷新。");
            return;
        }
        final long[] delays = new long[]{1200L, 2500L, 5000L};
        long delay = requestedDelayMs > 0 && reconnectAttempt == 0
                ? requestedDelayMs : delays[Math.min(reconnectAttempt, delays.length - 1)];
        final int nextAttempt = reconnectAttempt + 1;
        reconnectRunnable = () -> {
            reconnectRunnable = null;
            if (!autoReconnectEnabled || connected || gatt != null || isFinishing()) return;
            if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
                emitStatus(false, "等待蓝牙", "请打开手机蓝牙；下次下拉刷新可继续重连。", deviceName);
                scheduleReconnect(10000L);
                return;
            }
            reconnectAttempt = nextAttempt;
            emitStatus(false, "自动重连中", "正在进行第 " + reconnectAttempt + "/3 次重连…", deviceName);
            runWithPermissions(() -> connectInternal(rememberedAddress, deviceName, false));
        };
        main.postDelayed(reconnectRunnable, delay);
    }

    private void resumeAutoReconnect() {
        if (rememberedAddress == null || rememberedAddress.trim().isEmpty()) {
            emitError("还没有记住电池设备，请先扫描并连接一次 FD042884。");
            return;
        }
        autoReconnectEnabled = true;
        reconnectAttempt = 0;
        cancelReconnect();
        if (connected && ready) {
            autoRefresh = true;
            emitStatus(true, "已连接", "电池已连接，持续读取中。", deviceName);
            return;
        }
        if (gatt != null) disconnectInternal(false);
        emitLog("用户下拉刷新，已重新启动最多 3 次的自动重连流程。");
        emitStatus(false, "手动重连", "已恢复自动重连 FD042884…", deviceName);
        scheduleReconnect(300L);
    }

    private void handleUnexpectedDisconnect(BluetoothGatt source, String reason) {
        if (source == null || source != gatt) return;
        BluetoothGatt old = gatt;
        gatt = null;
        ready = false;
        connected = false;
        autoRefresh = false;
        readBusy = false;
        cancelPending();
        if (pollRunnable != null) main.removeCallbacks(pollRunnable);
        pollRunnable = null;
        writeCharacteristic = null;
        notifyCharacteristic = null;
        try { old.close(); } catch (Exception ignored) { }
        emitStatus(false, "连接中断", reason + "；正在自动重连 FD042884…", deviceName);
        emitLog("电池 BLE 连接中断：" + reason + "。已保留设备地址，准备自动重连。");
        if (autoReconnectEnabled) scheduleReconnect(1000L);
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (g != gatt) { try { g.close(); } catch (Exception ignored) { } return; }
            if (status != BluetoothGatt.GATT_SUCCESS) {
                handleUnexpectedDisconnect(g, "GATT 状态码 " + status);
                return;
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connected = true;
                emitLog("BLE 已连接，正在发现 Nordic UART 服务…");
                try { g.discoverServices(); }
                catch (Exception e) { handleUnexpectedDisconnect(g, "发现服务启动失败：" + e.getMessage()); }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                handleUnexpectedDisconnect(g, "电池断开连接");
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (g != gatt) return;
            if (status != BluetoothGatt.GATT_SUCCESS) { handleUnexpectedDisconnect(g, "发现 BLE 服务失败：" + status); return; }
            android.bluetooth.BluetoothGattService service = g.getService(UUID.fromString(SERVICE_UUID));
            if (service == null) { handleUnexpectedDisconnect(g, "未找到 Nordic UART 服务"); return; }
            writeCharacteristic = service.getCharacteristic(UUID.fromString(WRITE_UUID));
            notifyCharacteristic = service.getCharacteristic(UUID.fromString(NOTIFY_UUID));
            if (writeCharacteristic == null || notifyCharacteristic == null) {
                handleUnexpectedDisconnect(g, "未找到 BLE 写入或通知特征值"); return;
            }
            try {
                boolean ok = g.setCharacteristicNotification(notifyCharacteristic, true);
                BluetoothGattDescriptor descriptor = notifyCharacteristic.getDescriptor(UUID.fromString(CCCD_UUID));
                if (!ok || descriptor == null) { emitError("无法开启 BLE 通知。"); return; }
                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                boolean queued = g.writeDescriptor(descriptor);
                if (!queued) handleUnexpectedDisconnect(g, "BLE 通知订阅请求未进入队列");
            } catch (Exception e) { handleUnexpectedDisconnect(g, "开启 BLE 通知失败：" + e.getMessage()); }
        }

        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int status) {
            if (g != gatt) return;
            if (CCCD_UUID.equalsIgnoreCase(descriptor.getUuid().toString()) && status == BluetoothGatt.GATT_SUCCESS) {
                ready = true;
                reconnectAttempt = 0;
                cancelReconnect();
                connected = true;
                autoRefresh = true;
                monitorServiceStarted = BmsMonitorService.start(MainActivity.this, deviceName);
                if (!monitorServiceStarted) emitLog("Android 后台监控服务启动失败；请检查系统后台运行和通知权限设置。");
                emitStatus(true, "已连接", "蓝牙保持连接 · 后台监控已启动", deviceName);
                emitLog("Nordic UART 服务就绪，蓝牙保持连接，开始持续循环读取 20 串数据。");
                main.postDelayed(() -> {
                    if (ready && !readBusy) beginReadAll();
                }, 350);
            } else {
                handleUnexpectedDisconnect(g, "BLE 通知订阅失败：" + status);
            }
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            byte[] value = characteristic.getValue();
            if (value != null) main.post(() -> handleNotification(value.clone()));
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
            if (value != null) main.post(() -> handleNotification(value.clone()));
        }

        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic characteristic, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) emitError("BLE 写入请求失败：" + status);
        }
    };

    private void handleNotification(byte[] bytes) {
        String ascii = new String(bytes, StandardCharsets.US_ASCII);
        StringBuilder hex = new StringBuilder();
        for (byte b : bytes) hex.append(String.format(Locale.ROOT, "%02X", b & 0xff));
        JSONObject record = new JSONObject();
        try {
            record.put("time", nowIso());
            record.put("byteLength", bytes.length);
            record.put("hex", hex.toString());
            record.put("ascii", ascii);
        } catch (JSONException ignored) { }
        synchronized (notificationHistory) {
            notificationHistory.put(record);
            trimArray(notificationHistory, 250);
        }

        if (!waitingResponse) {
            synchronized (orphanHistory) { orphanHistory.put(record); trimArray(orphanHistory, 100); }
            emitLog("收到非请求期间 BLE 通知，已保留原始帧。");
            return;
        }
        String cleaned = ascii.toUpperCase(Locale.ROOT).replaceAll("[^0-9A-F]", "");
        rxBuffer += cleaned;
        try {
            ParsedFrame frame = tryParseFrame(rxBuffer, expectedCount, expectedAddress);
            if (frame == null) return;
            waitingResponse = false;
            if (responseTimeout != null) main.removeCallbacks(responseTimeout);
            rxBuffer = "";
            onBlockReceived(frame);
        } catch (Exception e) {
            cancelPending();
            abortRead("响应解析失败：" + e.getMessage());
        }
    }

    private void beginReadAll() {
        if (!ready || readBusy) return;
        readBusy = true;
        blockIndex = 0;
        currentFrames = new JSONArray();
        currentNotifications = new JSONArray();
        currentOrphans = new JSONArray();
        for (int i = 0; i < fullPayload.length; i++) fullPayload[i] = 0;
        readNextBlock();
    }

    private void readNextBlock() {
        if (!ready || !readBusy) return;
        if (blockIndex >= blockAddresses.length) {
            try {
                JSONObject data = decodePayload(fullPayload);
                JSONObject message = typeMessage("data");
                message.put("data", data);
                message.put("rawHex", bytesToHex(fullPayload));
                message.put("responseFrames", currentFrames);
                message.put("bleNotifications", snapshot(notificationHistory));
                message.put("orphanNotifications", snapshot(orphanHistory));
                emit(message);
                emitLog("完整读取成功：总压 " + data.getDouble("voltage") + "V，SOC " + data.getDouble("soc") + "%，电流 " + data.getDouble("currentA") + "A。");
            } catch (Exception e) {
                emitError("解析寄存器失败：" + e.getMessage());
            }
            readBusy = false;
            if (autoRefresh && ready) {
                if (pollRunnable != null) main.removeCallbacks(pollRunnable);
                pollRunnable = this::beginReadAll;
                main.postDelayed(pollRunnable, REFRESH_INTERVAL_MS);
            }
            return;
        }
        expectedAddress = blockAddresses[blockIndex];
        expectedCount = blockCounts[blockIndex];
        rxBuffer = "";
        waitingResponse = true;
        final int addressForTimeout = expectedAddress;
        responseTimeout = () -> {
            if (waitingResponse && expectedAddress == addressForTimeout) {
                waitingResponse = false;
                rxBuffer = "";
                abortRead("读取 0x" + Integer.toHexString(addressForTimeout).toUpperCase(Locale.ROOT) + " 超时；已停止本轮，避免迟到数据错配。");
            }
        };
        main.postDelayed(responseTimeout, RESPONSE_TIMEOUT_MS);
        String command = makeCommand(expectedAddress, expectedCount);
        emitLog("TX " + command + "（0x" + Integer.toHexString(expectedAddress).toUpperCase(Locale.ROOT) + " / " + expectedCount + " 字节）");
        try {
            byte[] ascii = command.getBytes(StandardCharsets.US_ASCII);
            if (Build.VERSION.SDK_INT >= 33) {
                int result = gatt.writeCharacteristic(writeCharacteristic, ascii, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                if (result != BluetoothGatt.GATT_SUCCESS) abortRead("发送读取命令失败，状态码 " + result);
            } else {
                writeCharacteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                writeCharacteristic.setValue(ascii);
                boolean ok = gatt.writeCharacteristic(writeCharacteristic);
                if (!ok) abortRead("发送读取命令未能进入 BLE 队列。");
            }
        } catch (Exception e) {
            abortRead("发送读取命令失败：" + e.getMessage());
        }
    }

    private void onBlockReceived(ParsedFrame frame) {
        int offset = blockOffsets[blockIndex];
        System.arraycopy(frame.payload, 0, fullPayload, offset, frame.payload.length);
        JSONObject item = new JSONObject();
        try {
            item.put("time", nowIso());
            item.put("address", String.format(Locale.ROOT, "0x%04X", expectedAddress));
            item.put("request", makeCommand(expectedAddress, expectedCount));
            item.put("response", frame.frame);
            item.put("payloadHex", bytesToHex(frame.payload));
            item.put("crc", frame.crc);
            item.put("crcValid", true);
            item.put("layout", frame.layout);
            currentFrames.put(item);
        } catch (JSONException ignored) { }
        emitLog("RX " + expectedCount + " 字节，CRC " + frame.crc + " 校验通过。");
        blockIndex++;
        if (blockIndex >= blockAddresses.length) readNextBlock();
        else main.postDelayed(this::readNextBlock, 650);
    }

    private void abortRead(String message) {
        cancelPending();
        readBusy = false;
        emitLog("本轮读取已中止：" + message);
        if (autoRefresh && ready) {
            if (pollRunnable != null) main.removeCallbacks(pollRunnable);
            pollRunnable = this::beginReadAll;
            main.postDelayed(pollRunnable, 2500);
        }
    }

    private void cancelPending() {
        waitingResponse = false;
        rxBuffer = "";
        if (responseTimeout != null) main.removeCallbacks(responseTimeout);
    }

    private ParsedFrame tryParseFrame(String buffer, int count, int address) throws Exception {
        int start = buffer.indexOf("F403");
        if (start < 0) {
            if (buffer.length() > 16) throw new Exception("响应中未找到 F403 帧头：" + buffer.substring(0, 16));
            return null;
        }
        String b = buffer.substring(start);
        if (b.length() < 6) return null;
        int payloadStart = 6;
        int countField = parseHexInt(b.substring(4, 6));
        String layout = "字节数响应";
        if (countField != count) {
            if (b.length() < 10) return null;
            int echoedAddress = parseHexInt(b.substring(4, 8));
            int echoedCount = parseHexInt(b.substring(8, 10));
            if (echoedAddress == address && echoedCount == count) {
                payloadStart = 10;
                layout = "地址+字节数回显响应";
            } else {
                throw new Exception("响应头不匹配：" + b.substring(0, 10));
            }
        }
        int totalChars = payloadStart + count * 2 + 4;
        if (b.length() < totalChars) return null;
        String frame = b.substring(0, totalChars);
        String receivedCrc = frame.substring(frame.length() - 4).toUpperCase(Locale.ROOT);
        byte[] crcBytes = hexToBytes(frame.substring(0, frame.length() - 4));
        String expectedCrc = crcText(crcBytes);
        if (!receivedCrc.equalsIgnoreCase(expectedCrc)) throw new Exception("CRC 错误：收到 " + receivedCrc + "，应为 " + expectedCrc);
        byte[] payload = hexToBytes(frame.substring(payloadStart, frame.length() - 4));
        return new ParsedFrame(frame, payload, receivedCrc, layout);
    }

    private JSONObject decodePayload(byte[] b) throws JSONException {
        if (b.length != 124) throw new JSONException("数据长度不是 124 字节");
        int voltageRaw = u16(b, 22);
        int socRaw = u16(b, 48);
        int remRaw = u16(b, 52);
        int ratedRaw = u16(b, 56);
        int sohRaw = u16(b, 50); // BMS SOH word: 0-1000 represents 0.0%-100.0%
        Double sohPercent = sohRaw > 0 && sohRaw <= 1000 ? sohRaw / 10.0 : null;
        int cycle = u16(b, 60);
        int series = ((b[62] & 0xff) << 8) | (b[63] & 0xff);
        double soc = socRaw / 10.0;
        double voltage = voltageRaw / 100.0;
        double rated = ratedRaw > 0 ? ratedRaw / 1000.0 : 24.0;
        boolean remValid = remRaw > 0 && (ratedRaw == 0 || remRaw <= ratedRaw * 1.2);
        double remaining = remValid ? remRaw / 1000.0 : rated * soc / 100.0;
        JSONObject temperatures = new JSONObject();
        putNullable(temperatures, "cell", readTemp(b, 28));
        putNullable(temperatures, "ambient", readTemp(b, 30));
        putNullable(temperatures, "mos", readTemp(b, 32));
        JSONArray probes = new JSONArray();
        for (int offset : new int[]{116, 118, 120, 122}) {
            Double t = readTemp(b, offset);
            probes.put(t == null ? JSONObject.NULL : t);
        }
        int currentUnsigned = u16(b, 26);
        int currentSigned = (short) currentUnsigned;
        double currentA = currentSigned / 100.0;
        double powerW = Math.abs(voltage * currentA);

        JSONArray cells = new JSONArray();
        int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE, sum = 0, valid = 0;
        for (int i = 0; i < 20; i++) {
            int offset = 68 + i * 2;
            int raw = u16(b, offset);
            boolean good = raw >= 2000 && raw <= 4500 && raw != 65535;
            JSONObject c = new JSONObject();
            c.put("index", i + 1);
            c.put("mv", good ? raw : JSONObject.NULL);
            c.put("raw", raw);
            c.put("offset", offset);
            cells.put(c);
            if (good) { valid++; min = Math.min(min, raw); max = Math.max(max, raw); sum += raw; }
        }
        boolean all = valid == 20;
        double cellSum = all ? sum / 1000.0 : Double.NaN;
        double delta = all ? Math.abs(cellSum - voltage) : Double.NaN;

        JSONArray words = new JSONArray();
        for (int offset = 0; offset < 124; offset += 2) {
            JSONObject w = new JSONObject();
            w.put("offset", offset);
            w.put("hex", String.format(Locale.ROOT, "%02X%02X", b[offset] & 0xff, b[offset + 1] & 0xff));
            w.put("u16", u16(b, offset));
            w.put("s16", (short) u16(b, offset));
            words.put(w);
        }

        JSONObject out = new JSONObject();
        out.put("voltage", voltage); out.put("voltageRaw", voltageRaw);
        out.put("soc", soc); out.put("socRaw", socRaw);
        out.put("remainingCapacityAh", remaining); out.put("ratedCapacityAh", rated);
        out.put("capacitySource", remValid ? "bms" : "soc_estimate");
        out.put("sohPercent", sohPercent == null ? JSONObject.NULL : sohPercent);
        out.put("sohRaw", sohRaw);
        out.put("sohRegisterOffset", 50);
        out.put("remainingCapacityRaw", remRaw); out.put("ratedCapacityRaw", ratedRaw);
        out.put("cycleCount", cycle); out.put("seriesCount", series);
        out.put("temperatures", temperatures); out.put("probes", probes);
        out.put("currentRegisterOffset", 26); out.put("currentScaleA", 0.01);
        out.put("currentRawCandidate", currentSigned); out.put("currentRawUnsigned", currentUnsigned);
        out.put("currentRawSigned", currentSigned); out.put("currentA", currentA); out.put("powerW", powerW);
        out.put("auxWord24Unsigned", u16(b, 24)); out.put("auxWord24Signed", (short) u16(b, 24));
        out.put("cells", cells);
        out.put("min", all ? min : JSONObject.NULL); out.put("max", all ? max : JSONObject.NULL);
        out.put("spread", all ? max - min : JSONObject.NULL);
        out.put("sum", all ? cellSum : JSONObject.NULL); out.put("delta", all ? delta : JSONObject.NULL);
        out.put("sumMatches", all && delta <= 0.05); out.put("allPresent", all); out.put("validCellCount", valid);
        out.put("registerWords", words); out.put("rawHex", bytesToHex(b));
        return out;
    }

    private Double readTemp(byte[] b, int offset) {
        int raw = u16(b, offset);
        if (raw == 65535 || raw > 1000) return null;
        return raw / 10.0;
    }

    private boolean hasPreciseLocationPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasAnyLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void withLocationPermission(Runnable granted, Runnable denied) {
        if (hasAnyLocationPermission()) {
            if (granted != null) granted.run();
            return;
        }
        if (granted != null) locationGrantedCallbacks.add(granted);
        if (denied != null) locationDeniedCallbacks.add(denied);
        if (locationPermissionPending) return;
        locationPermissionPending = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION_PERMISSION);
        } else {
            locationPermissionPending = false;
            ArrayList<Runnable> callbacks = new ArrayList<>(locationGrantedCallbacks);
            locationGrantedCallbacks.clear(); locationDeniedCallbacks.clear();
            for (Runnable callback : callbacks) callback.run();
        }
    }

    private void startLocationTracking() {
        withLocationPermission(this::startLocationTrackingInternal, null);
    }

    private void startLocationTrackingInternal() {
        BmsMonitorService.setRideActive(this, true);
        if (locationTracking) {
            emitLocationStatus(true, "手机定位已在运行，等待有效 GPS 坐标。", true);
            return;
        }
        if (!hasAnyLocationPermission()) {
            emitLocationStatus(false, "缺少定位权限，请重新点击定位按钮授权。", false);
            return;
        }
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) {
            emitLocationStatus(false, "手机定位服务不可用。", false);
            return;
        }
        locationListener = new LocationListener() {
            @Override public void onLocationChanged(Location location) {
                if (location == null) return;
                JSONObject msg = typeMessage("location");
                try {
                    msg.put("latitude", location.getLatitude());
                    msg.put("longitude", location.getLongitude());
                    msg.put("accuracy", location.hasAccuracy() ? location.getAccuracy() : JSONObject.NULL);
                    msg.put("hasSpeed", location.hasSpeed());
                    msg.put("speedMps", location.hasSpeed() ? location.getSpeed() : JSONObject.NULL);
                    msg.put("speedAccuracyMps", Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && location.hasSpeedAccuracy()
                            ? location.getSpeedAccuracyMetersPerSecond() : JSONObject.NULL);
                    msg.put("altitude", location.hasAltitude() ? location.getAltitude() : JSONObject.NULL);
                    msg.put("time", location.getTime());
                    msg.put("provider", location.getProvider() == null ? "unknown" : location.getProvider());
                } catch (JSONException ignored) { }
                emit(msg);
            }
            @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
            @Override public void onProviderEnabled(String provider) { emitLocationStatus(true, provider + " 定位已开启，等待坐标。", true); }
            @Override public void onProviderDisabled(String provider) { emitLocationStatus(locationTracking, provider + " 定位暂不可用，请检查系统定位开关。", locationTracking); }
        };

        boolean gpsEnabled = false, networkEnabled = false, requested = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && !locationManager.isLocationEnabled()) {
                emitLocationStatus(false, "手机系统定位总开关未开启。请先打开系统定位，再点「重新开启定位」。", false);
                return;
            }
            gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            try { networkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER); }
            catch (Exception ignored) { networkEnabled = false; }

            if (hasPreciseLocationPermission() && gpsEnabled) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0.5f, locationListener, main.getLooper());
                requested = true;
            }
            if ((hasPreciseLocationPermission() || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    && networkEnabled) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 1.0f, locationListener, main.getLooper());
                requested = true;
            }
        } catch (SecurityException e) {
            emitLocationStatus(false, "定位权限仍不可用。请在系统设置中允许精确位置，然后重新开启定位。", false);
            return;
        } catch (Exception e) {
            emitLocationStatus(false, "启动手机定位失败：" + e.getMessage(), false);
            return;
        }
        if (!requested) {
            String message = (!gpsEnabled && !networkEnabled)
                    ? "手机系统定位服务未开启或当前设备没有可用定位源。请打开系统定位，并到室外等待 GPS 信号。"
                    : "当前定位权限不足。请将 BYD BMS 的位置权限设为「使用时允许」并开启「精确位置」。";
            emitLocationStatus(false, message, false);
            return;
        }
        locationTracking = true;
        String startupMessage;
        if (!hasPreciseLocationPermission()) startupMessage = "已启动大致位置定位；为获得准确骑行速度，请允许精确位置。";
        else if (!gpsEnabled) startupMessage = "GPS 暂不可用，正在尝试网络定位；请到室外获取精确 GPS。";
        else startupMessage = "GPS 已启动，正在等待卫星定位；请到室外空旷处。";
        emitLocationStatus(true, startupMessage, true);

        try {
            Location last = null;
            String[] providers = new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER};
            for (String provider : providers) {
                try {
                    if (!locationManager.isProviderEnabled(provider)) continue;
                    Location candidate = locationManager.getLastKnownLocation(provider);
                    if (candidate != null && (last == null || candidate.getTime() > last.getTime())) last = candidate;
                } catch (SecurityException | IllegalArgumentException ignored) { }
            }
            if (last != null) {
                JSONObject msg = typeMessage("location");
                msg.put("latitude", last.getLatitude());
                msg.put("longitude", last.getLongitude());
                msg.put("accuracy", last.hasAccuracy() ? last.getAccuracy() : JSONObject.NULL);
                msg.put("hasSpeed", last.hasSpeed());
                msg.put("speedMps", last.hasSpeed() ? last.getSpeed() : JSONObject.NULL);
                msg.put("speedAccuracyMps", Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && last.hasSpeedAccuracy()
                        ? last.getSpeedAccuracyMetersPerSecond() : JSONObject.NULL);
                msg.put("altitude", last.hasAltitude() ? last.getAltitude() : JSONObject.NULL);
                msg.put("time", last.getTime());
                msg.put("provider", last.getProvider() == null ? "unknown" : last.getProvider());
                emit(msg);
            }
        } catch (Exception ignored) { }
    }

    private void stopLocationTracking() {
        if (locationManager != null && locationListener != null) {
            try { locationManager.removeUpdates(locationListener); } catch (SecurityException ignored) { }
        }
        locationListener = null;
        locationTracking = false;
        emitLocationStatus(false, "行程定位已结束", false);
    }

    private void emitLocationStatus(boolean tracking, String message, boolean active) {
        JSONObject obj = typeMessage("locationStatus");
        try { obj.put("tracking", tracking); obj.put("active", active); obj.put("message", message); }
        catch (JSONException ignored) { }
        emit(obj);
    }

    private void emitLocationStatus(boolean tracking, String message) {
        emitLocationStatus(tracking, message, tracking);
    }

    @Override protected void onResume() {
        super.onResume();
        BmsMonitorService.setBackground(this, false);
        if (overlaySettingsOpened) {
            overlaySettingsOpened = false;
            if (Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this))
                Toast.makeText(this, "后台悬浮窗已启用。切出应用后会显示实时状态。", Toast.LENGTH_SHORT).show();
        }
        // Keep the visible ride display awake and restart location after returning from system settings.
        if (tripScreenOn) {
            getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (webView != null) webView.setKeepScreenOn(true);
            if (!locationTracking && hasAnyLocationPermission()) main.postDelayed(this::startLocationTrackingInternal, 250L);
        }
        if (autoReconnectEnabled && rememberedAddress != null && !connected && gatt == null) scheduleReconnect(1500L);
    }

    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        BmsMonitorService.setBackground(this, true);
    }

    @Override protected void onStop() {
        if (!isChangingConfigurations()) BmsMonitorService.setBackground(this, true);
        super.onStop();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && tripScreenOn) setTripScreenOn(true);
    }

    private void setTripScreenOn(boolean enabled) {
        tripScreenOn = enabled;
        if (webView != null) webView.setKeepScreenOn(enabled);
        if (enabled) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void disconnectInternal(boolean notifyUi) {
        autoRefresh = false;
        ready = false;
        connected = false;
        readBusy = false;
        cancelPending();
        if (pollRunnable != null) main.removeCallbacks(pollRunnable);
        pollRunnable = null;
        BluetoothGatt old = gatt;
        gatt = null;
        writeCharacteristic = null;
        notifyCharacteristic = null;
        if (old != null) {
            try { old.disconnect(); } catch (Exception ignored) { }
            try { old.close(); } catch (Exception ignored) { }
        }
        if (notifyUi) emitStatus(false, "未连接", "蓝牙连接已断开", deviceName);
    }

    private void manualDisconnect() {
        autoReconnectEnabled = false;
        cancelReconnect();
        disconnectInternal(true);
        BmsMonitorService.stop(this);
        monitorServiceStarted = false;
    }

    private void keepBatteryConnected() {
        if (rememberedAddress == null || rememberedAddress.trim().isEmpty()) return;
        autoReconnectEnabled = true;
        if (connected && ready) {
            autoRefresh = true;
            if (!readBusy) {
                if (pollRunnable != null) main.removeCallbacks(pollRunnable);
                pollRunnable = this::beginReadAll;
                main.postDelayed(pollRunnable, REFRESH_INTERVAL_MS);
            }
        } else {
            scheduleReconnect(500L);
        }
    }

    private class BmsBridge {
        @JavascriptInterface public void startScan() {
            main.post(() -> runWithPermissions(() -> startScanInternal()));
        }
        @JavascriptInterface public void connect(String address, String name) {
            main.post(() -> runWithPermissions(() -> connectInternal(address, name)));
        }
        @JavascriptInterface public void readAll() { main.post(() -> beginReadAll()); }
        @JavascriptInterface public void disconnect() { main.post(() -> manualDisconnect()); }
        @JavascriptInterface public void startLocationTracking() { main.post(() -> MainActivity.this.startLocationTracking()); }
        @JavascriptInterface public void stopLocationTracking() { main.post(() -> MainActivity.this.stopLocationTracking()); }
        @JavascriptInterface public void setTripScreenOn(boolean enabled) { main.post(() -> MainActivity.this.setTripScreenOn(enabled)); }
        @JavascriptInterface public void setAutoRefresh(boolean enabled) {
            main.post(() -> {
                autoRefresh = enabled;
                if (!enabled) {
                    if (pollRunnable != null) main.removeCallbacks(pollRunnable);
                    pollRunnable = null;
                } else if (ready && !readBusy) {
                    if (pollRunnable != null) main.removeCallbacks(pollRunnable);
                    pollRunnable = MainActivity.this::beginReadAll;
                    main.postDelayed(pollRunnable, REFRESH_INTERVAL_MS);
                }
            });
        }
        @JavascriptInterface public void keepBatteryConnected() { main.post(() -> MainActivity.this.keepBatteryConnected()); }
        @JavascriptInterface public void resumeAutoReconnect() { main.post(() -> MainActivity.this.resumeAutoReconnect()); }
        @JavascriptInterface public void requestBackgroundMonitorAccess() { main.post(() -> MainActivity.this.requestBackgroundMonitorAccess()); }
        @JavascriptInterface public void setRideActive(boolean active) { main.post(() -> BmsMonitorService.setRideActive(MainActivity.this, active)); }
        @JavascriptInterface public void exportDiagnostic(String json) {
            main.post(() -> beginExport(json));
        }
    }

    private void beginExport(String json) {
        pendingExportJson = json;
        String filename = "BYD-BMS-0.24-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) + ".json";
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(intent, CREATE_DIAGNOSTIC);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_DIAGNOSTIC && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
                if (stream == null) throw new IllegalStateException("无法打开保存位置");
                stream.write((pendingExportJson == null ? "{}" : pendingExportJson).getBytes(StandardCharsets.UTF_8));
                stream.flush();
                emit(new JSONObject().put("type", "exported").put("message", "诊断 JSON 已保存到你选择的位置。"));
            } catch (Exception e) {
                emitError("保存诊断文件失败：" + e.getMessage());
            }
        }
        pendingExportJson = null;
    }

    private void emitStatus(boolean on, String title, String caption, String name) {
        JSONObject obj = typeMessage("status");
        try { obj.put("connected", on); obj.put("title", title); obj.put("caption", caption); obj.put("name", name); }
        catch (JSONException ignored) { }
        emit(obj);
    }
    private void emitLog(String message) {
        JSONObject obj = typeMessage("log");
        try { obj.put("message", message); } catch (JSONException ignored) { }
        emit(obj);
    }
    private void emitError(String message) {
        JSONObject obj = typeMessage("error");
        try { obj.put("message", message); } catch (JSONException ignored) { }
        emit(obj);
    }
    private JSONObject typeMessage(String type) {
        JSONObject obj = new JSONObject();
        try { obj.put("type", type); } catch (JSONException ignored) { }
        return obj;
    }
    private void emit(JSONObject message) {
        if (monitorServiceStarted && message != null) {
            String type = message.optString("type", "");
            if ("data".equals(type)) {
                JSONObject compact = new JSONObject();
                try {
                    compact.put("type", "data");
                    compact.put("data", message.optJSONObject("data"));
                    compact.put("rawHex", message.optString("rawHex", ""));
                } catch (JSONException ignored) { }
                BmsMonitorService.update(this, compact);
            } else if ("status".equals(type)) BmsMonitorService.update(this, message);
            else if ("location".equals(type)) BmsMonitorService.update(this, message);
        }
        if (webView == null) return;
        String json = message.toString();
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript("window.onNativeMessage && window.onNativeMessage(" + json + ");", null);
        });
    }

    private static int u16(byte[] b, int offset) { return (b[offset] & 0xff) | ((b[offset + 1] & 0xff) << 8); }
    private static String bytesToHex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02X", b & 0xff));
        return out.toString();
    }
    private static byte[] hexToBytes(String hex) {
        if ((hex.length() & 1) != 0) throw new IllegalArgumentException("HEX 长度不是偶数");
        byte[] out = new byte[hex.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
        return out;
    }
    private static int parseHexInt(String value) { return Integer.parseInt(value, 16); }
    private static int crc16Modbus(byte[] bytes) {
        int crc = 0xffff;
        for (byte value : bytes) {
            crc ^= value & 0xff;
            for (int i = 0; i < 8; i++) crc = ((crc & 1) != 0) ? ((crc >>> 1) ^ 0xa001) : (crc >>> 1);
        }
        return crc & 0xffff;
    }
    private static String crcText(byte[] bytes) {
        int crc = crc16Modbus(bytes);
        return String.format(Locale.ROOT, "%02X%02X", crc & 0xff, (crc >>> 8) & 0xff);
    }
    private static String makeCommand(int address, int count) {
        byte[] header = new byte[]{(byte) 0xf4, 0x03, (byte) ((address >>> 8) & 0xff), (byte) (address & 0xff), (byte) count};
        return bytesToHex(header) + crcText(header);
    }
    private static void putNullable(JSONObject obj, String key, Double value) throws JSONException {
        obj.put(key, value == null ? JSONObject.NULL : value);
    }
    private static String nowIso() { return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(new Date()); }
    private static JSONArray snapshot(JSONArray source) {
        JSONArray copy = new JSONArray();
        synchronized (source) { for (int i = 0; i < source.length(); i++) copy.put(source.opt(i)); }
        return copy;
    }
    private static void trimArray(JSONArray array, int max) {
        // JSON arrays are append-only in Android's org.json API; keep the newest bounded tail by rebuilding.
        if (array.length() <= max) return;
        JSONArray keep = new JSONArray();
        for (int i = array.length() - max; i < array.length(); i++) keep.put(array.opt(i));
        for (int i = array.length() - 1; i >= 0; i--) array.remove(i);
        for (int i = 0; i < keep.length(); i++) array.put(keep.opt(i));
    }

    private static class ParsedFrame {
        final String frame;
        final byte[] payload;
        final String crc;
        final String layout;
        ParsedFrame(String frame, byte[] payload, String crc, String layout) {
            this.frame = frame; this.payload = payload; this.crc = crc; this.layout = layout;
        }
    }

    private void dispatchBackToWeb() {
        // All app screens are states inside the single WebView page. Let its state
        // handler close overlays / return to the previous screen, and consume Back
        // on the dashboard root instead of unexpectedly finishing MainActivity.
        if (webView != null) {
            try { webView.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : true;", null); }
            catch (Exception ignored) { }
        }
    }

    @Override public void onBackPressed() {
        dispatchBackToWeb();
    }

    @Override protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backInvokedCallback != null) {
            try { getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backInvokedCallback); }
            catch (Exception ignored) { }
        }
        stopScanInternal();
        if (isFinishing()) {
            autoReconnectEnabled = false;
            cancelReconnect();
            autoRefresh = false;
            stopLocationTracking();
            setTripScreenOn(false);
            disconnectInternal(false);
            BmsMonitorService.stop(this);
            monitorServiceStarted = false;
        }
        if (webView != null) { webView.removeJavascriptInterface("BmsNative"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
