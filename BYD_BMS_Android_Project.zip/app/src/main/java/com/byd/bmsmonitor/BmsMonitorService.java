package com.byd.bmsmonitor;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.GridLayout;
import android.widget.TextView;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Locale;
import java.util.zip.GZIPOutputStream;

/** Keeps the connected BMS session visible to Android while the dashboard is backgrounded. */
public class BmsMonitorService extends Service {
    public static final String ACTION_START = "com.byd.bmsmonitor.action.START";
    public static final String ACTION_UPDATE = "com.byd.bmsmonitor.action.UPDATE";
    public static final String ACTION_BACKGROUND = "com.byd.bmsmonitor.action.BACKGROUND";
    public static final String ACTION_FOREGROUND = "com.byd.bmsmonitor.action.FOREGROUND";
    public static final String ACTION_RIDE = "com.byd.bmsmonitor.action.RIDE";
    public static final String ACTION_STOP = "com.byd.bmsmonitor.action.STOP";
    private static final String CHANNEL_ID = "byd_bms_live_monitor";
    private static final int NOTIFICATION_ID = 2301;
    private static final String DB_NAME = "byd_background_samples.db";
    private static final int MAX_SAMPLES = 100000;
    private static final long RETENTION_MS = 30L * 24L * 60L * 60L * 1000L;
    private static volatile BmsMonitorService instance;

    private NotificationManager notificationManager;
    private WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams overlayParams;
    private TextView overlayTitle, overlaySoc;
    private final TextView[] overlayMetrics = new TextView[4];
    private boolean appInBackground;
    private boolean rideActive;
    private boolean overlayDismissed;
    private boolean foregroundStarted;
    private long sampleCount;
    private long locationSampleCount;
    private long lastNotificationUpdate;
    private JSONObject latestData = new JSONObject();
    private String connectionTitle = "已连接";
    private String deviceName = "FD042884";
    private PowerManager.WakeLock wakeLock;
    private SampleDb sampleDb;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService storageExecutor = Executors.newSingleThreadExecutor();

    public static boolean isRunning() { return instance != null; }

    public static boolean start(Context context, String name) {
        Intent i = new Intent(context, BmsMonitorService.class).setAction(ACTION_START);
        i.putExtra("deviceName", name == null ? "FD042884" : name);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i);
            else context.startService(i);
            return true;
        } catch (Exception ignored) { return false; }
    }

    public static void update(Context context, JSONObject message) {
        BmsMonitorService service = instance;
        if (service == null || message == null) return;
        service.mainHandler.post(() -> service.handleUpdate(message.toString()));
    }

    public static void setBackground(Context context, boolean background) {
        BmsMonitorService service = instance;
        if (service == null) return;
        service.mainHandler.post(() -> {
            service.appInBackground = background;
            if (background) {
                service.acquireWakeLock();
                service.overlayDismissed = false;
                service.showOverlayIfAllowed();
                service.updateOverlay();
            } else {
                service.hideOverlay();
                if (!service.rideActive) service.releaseWakeLock();
            }
        });
    }

    public static void setRideActive(Context context, boolean active) {
        BmsMonitorService service = instance;
        if (service == null) return;
        service.mainHandler.post(() -> {
            service.rideActive = active;
            service.updateForegroundType();
            if (active || service.appInBackground) service.acquireWakeLock(); else service.releaseWakeLock();
            if (!active && !service.appInBackground) service.hideOverlay();
            service.updateNotification();
        });
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, BmsMonitorService.class));
    }

    @Override public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        sampleDb = new SampleDb(this);
        instance = this;
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            ensureForeground();
            updateNotification();
            return START_STICKY;
        }
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent.hasExtra("deviceName")) deviceName = intent.getStringExtra("deviceName");
        ensureForeground();
        if (ACTION_UPDATE.equals(action)) handleUpdate(intent.getStringExtra("message"));
        else if (ACTION_BACKGROUND.equals(action)) {
            appInBackground = true;
            overlayDismissed = false;
            showOverlayIfAllowed();
            updateOverlay();
        } else if (ACTION_FOREGROUND.equals(action)) {
            appInBackground = false;
            hideOverlay();
        } else if (ACTION_RIDE.equals(action)) {
            rideActive = intent.getBooleanExtra("active", false);
            updateForegroundType();
            if (rideActive || appInBackground) acquireWakeLock(); else releaseWakeLock();
            if (!rideActive && !appInBackground) hideOverlay();
        }
        updateNotification();
        return START_STICKY;
    }

    private void ensureForeground() {
        if (foregroundStarted) return;
        Notification notification = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            } else startForeground(NOTIFICATION_ID, notification);
            foregroundStarted = true;
        } catch (Exception e) {
            // Still try the legacy overload on OEM builds that reject an advertised type.
            try { startForeground(NOTIFICATION_ID, notification); foregroundStarted = true; }
            catch (Exception ignored) { }
        }
    }

    private void updateForegroundType() {
        if (Build.VERSION.SDK_INT < 29 || !foregroundStarted) return;
        int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
        boolean locationGranted = checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (rideActive && locationGranted) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
        try { startForeground(NOTIFICATION_ID, buildNotification(), type); }
        catch (Exception ignored) { }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "BYD BMS 实时监控", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("蓝牙电池状态和后台骑行监控");
            channel.setShowBadge(false);
            channel.setSound(null, null);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        String state = rideActive ? "后台骑行记录中" : connectionTitle;
        String line = formatNotificationLine();
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle("BYD BMS · " + state)
                .setContentText(line)
                .setStyle(new Notification.BigTextStyle().bigText(line + (rideActive ? " · 行程数据正在本机记录" : " · 蓝牙持续监控中")))
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setPriority(Notification.PRIORITY_LOW);
        return b.build();
    }

    private String formatNotificationLine() {
        double voltage = latestData.optDouble("voltage", Double.NaN);
        double soc = latestData.optDouble("soc", Double.NaN);
        double current = latestData.optDouble("currentA", Double.NaN);
        double power = latestData.optDouble("powerW", Double.NaN);
        StringBuilder s = new StringBuilder(deviceName == null ? "FD042884" : deviceName);
        if (Double.isFinite(soc)) s.append("  ·  SOC ").append(String.format(Locale.US, "%.1f%%", soc));
        if (Double.isFinite(voltage)) s.append("  ·  ").append(String.format(Locale.US, "%.1fV", voltage));
        if (Double.isFinite(current)) s.append("  ·  ").append(String.format(Locale.US, "%.2fA", current));
        if (Double.isFinite(power)) s.append("  ·  ").append(String.format(Locale.US, "%.0fW", power));
        return s.toString();
    }

    private void updateNotification() {
        if (!foregroundStarted || notificationManager == null) return;
        long now = System.currentTimeMillis();
        if (now - lastNotificationUpdate < 900) return;
        lastNotificationUpdate = now;
        try { notificationManager.notify(NOTIFICATION_ID, buildNotification()); } catch (Exception ignored) { }
    }

    private void handleUpdate(String raw) {
        if (raw == null) return;
        try {
            JSONObject message = new JSONObject(raw);
            String type = message.optString("type", "");
            if ("status".equals(type)) {
                connectionTitle = message.optBoolean("connected", false)
                        ? "已连接" : message.optString("title", "等待连接");
                String name = message.optString("name", "");
                if (!name.isEmpty()) deviceName = name;
            } else if ("data".equals(type)) {
                JSONObject data = message.optJSONObject("data");
                if (data != null) {
                    latestData = data;
                    if (appInBackground || rideActive) saveSample(data, message.optString("rawHex", ""));
                    updateOverlay();
                }
            } else if ("location".equals(type) && (appInBackground || rideActive)) {
                saveLocationSample(message);
            }
        } catch (Exception ignored) { }
        updateNotification();
    }

    private void saveSample(JSONObject data, String rawHex) {
        final String dataText = data.toString();
        final String hex = rawHex == null ? "" : rawHex;
        storageExecutor.execute(() -> {
            try {
                JSONObject record = new JSONObject();
                record.put("time", System.currentTimeMillis());
                record.put("data", new JSONObject(dataText));
                if (!hex.isEmpty()) record.put("rawHex", hex);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (GZIPOutputStream gzip = new GZIPOutputStream(bytes)) {
                    gzip.write(record.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
                }
                SQLiteDatabase db = sampleDb.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("created_at", System.currentTimeMillis());
                values.put("payload_gzip", bytes.toByteArray());
                db.insert("samples", null, values);
                if (++sampleCount % 50 == 0) {
                    long cutoff = System.currentTimeMillis() - RETENTION_MS;
                    db.delete("samples", "created_at < ?", new String[]{String.valueOf(cutoff)});
                    db.execSQL("DELETE FROM samples WHERE _id NOT IN (SELECT _id FROM samples ORDER BY _id DESC LIMIT " + MAX_SAMPLES + ")");
                }
            } catch (Exception ignored) { }
        });
    }

    private void saveLocationSample(JSONObject location) {
        final String locationText = location.toString();
        storageExecutor.execute(() -> {
            try {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (GZIPOutputStream gzip = new GZIPOutputStream(bytes)) {
                    gzip.write(locationText.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                }
                SQLiteDatabase db = sampleDb.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("created_at", System.currentTimeMillis());
                values.put("payload_gzip", bytes.toByteArray());
                db.insert("locations", null, values);
                if (++locationSampleCount % 50 == 0) {
                    long cutoff = System.currentTimeMillis() - RETENTION_MS;
                    db.delete("locations", "created_at < ?", new String[]{String.valueOf(cutoff)});
                    db.execSQL("DELETE FROM locations WHERE _id NOT IN (SELECT _id FROM locations ORDER BY _id DESC LIMIT " + MAX_SAMPLES + ")");
                }
            } catch (Exception ignored) { }
        });
    }

    private void showOverlayIfAllowed() {
        if (overlayView != null || overlayDismissed || Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) return;
        try {
            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(9), dp(7), dp(9), dp(8));
            root.setMinimumHeight(dp(118));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xF018202D);
            bg.setCornerRadius(dp(13));
            bg.setStroke(dp(1), 0xFF18B990);
            root.setBackground(bg);
            root.setElevation(dp(10));

            LinearLayout heading = new LinearLayout(this);
            heading.setGravity(Gravity.CENTER_VERTICAL);
            TextView title = text("BYD BMS  ·  实时状态", 10, 0xFF9ADFCF, true);
            title.setGravity(Gravity.CENTER_VERTICAL);
            heading.addView(title, new LinearLayout.LayoutParams(0, dp(21), 1));
            TextView close = text("×", 19, 0xFFB9C5D4, true);
            close.setGravity(Gravity.CENTER);
            heading.addView(close, new LinearLayout.LayoutParams(dp(24), dp(22)));
            close.setOnClickListener(v -> { overlayDismissed = true; hideOverlay(); });
            root.addView(heading);

            overlaySoc = text("SOC  --%", 18, 0xFF20D6A0, true);
            overlaySoc.setGravity(Gravity.CENTER);
            overlaySoc.setPadding(0, dp(2), 0, dp(4));
            root.addView(overlaySoc, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(30)));

            GridLayout grid = new GridLayout(this);
            grid.setColumnCount(2);
            grid.setRowCount(2);
            String[] initial = new String[]{"电压  --.- V", "电流  --.-- A", "功率  ---- W", "温度  --.- °C"};
            for (int i = 0; i < 4; i++) {
                TextView tile = text(initial[i], 10, 0xFFE5ECF5, true);
                tile.setGravity(Gravity.CENTER);
                tile.setSingleLine(true);
                tile.setPadding(dp(3), 0, dp(3), 0);
                GradientDrawable tileBg = new GradientDrawable();
                tileBg.setColor(0xFF253142);
                tileBg.setCornerRadius(dp(7));
                tileBg.setStroke(dp(1), 0xFF34465A);
                tile.setBackground(tileBg);
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                        GridLayout.spec(GridLayout.UNDEFINED, 1f),
                        GridLayout.spec(GridLayout.UNDEFINED, 1f));
                lp.width = 0;
                lp.height = dp(29);
                lp.setMargins(dp(2), dp(2), dp(2), dp(2));
                lp.setGravity(Gravity.FILL);
                grid.addView(tile, lp);
                overlayMetrics[i] = tile;
            }
            root.addView(grid, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(64)));
            overlayTitle = title;
            overlayView = root;

            int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
            overlayParams = new WindowManager.LayoutParams(dp(224), WindowManager.LayoutParams.WRAP_CONTENT, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            overlayParams.gravity = Gravity.TOP | Gravity.END;
            overlayParams.x = dp(12); overlayParams.y = dp(150);
            root.setOnTouchListener(new View.OnTouchListener() {
                float downX, downY; int startX, startY;
                @Override public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN: downX = event.getRawX(); downY = event.getRawY(); startX = overlayParams.x; startY = overlayParams.y; return true;
                        case MotionEvent.ACTION_MOVE:
                            if (Math.abs(event.getRawX() - downX) > dp(3) || Math.abs(event.getRawY() - downY) > dp(3)) {
                                overlayParams.x = Math.max(0, startX + (int)(downX - event.getRawX()));
                                overlayParams.y = Math.max(0, startY + (int)(event.getRawY() - downY));
                                try { windowManager.updateViewLayout(overlayView, overlayParams); } catch (Exception ignored) { }
                                return true;
                            }
                            return false;
                        default: return false;
                    }
                }
            });
            windowManager.addView(overlayView, overlayParams);
            updateOverlay();
        } catch (Exception e) { hideOverlay(); }
    }

    private void updateOverlay() {
        if (overlayView == null || latestData == null) return;
        double soc = latestData.optDouble("soc", Double.NaN);
        double voltage = latestData.optDouble("voltage", Double.NaN);
        double current = latestData.optDouble("currentA", Double.NaN);
        double power = latestData.optDouble("powerW", Double.NaN);
        double temp = Double.NaN;
        JSONObject temps = latestData.optJSONObject("temperatures");
        if (temps != null) temp = temps.optDouble("cell", Double.NaN);
        if (overlayTitle != null) overlayTitle.setText("BYD BMS  ·  " + (connectionTitle == null ? "实时状态" : connectionTitle));
        if (overlaySoc != null) overlaySoc.setText("SOC  " + (Double.isFinite(soc) ? String.format(Locale.US, "%.1f%%", soc) : "--%"));
        String[] values = new String[]{
                "电压  " + (Double.isFinite(voltage) ? String.format(Locale.US, "%.1f V", voltage) : "--.- V"),
                "电流  " + (Double.isFinite(current) ? String.format(Locale.US, "%.2f A", current) : "--.-- A"),
                "功率  " + (Double.isFinite(power) ? String.format(Locale.US, "%.0f W", power) : "---- W"),
                "温度  " + (Double.isFinite(temp) ? String.format(Locale.US, "%.1f °C", temp) : "--.- °C")
        };
        for (int i = 0; i < overlayMetrics.length; i++) {
            if (overlayMetrics[i] != null) overlayMetrics[i].setText(values[i]);
        }
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void hideOverlay() {
        if (overlayView != null && windowManager != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) { }
        }
        overlayView = null; overlayParams = null; overlayTitle = null; overlaySoc = null;
        for (int i = 0; i < overlayMetrics.length; i++) overlayMetrics[i] = null;
    }

    private void acquireWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) return;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BYDBMS:BackgroundRideMonitor");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire();
            }
        } catch (Exception ignored) { }
    }

    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
        wakeLock = null;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Keep the foreground monitor alive when the user removes only the dashboard task.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        hideOverlay(); releaseWakeLock();
        if (foregroundStarted) stopForeground(true);
        storageExecutor.shutdown();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private static class SampleDb extends SQLiteOpenHelper {
        SampleDb(Context c) { super(c, DB_NAME, null, 1); }
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE samples (_id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER NOT NULL, payload_gzip BLOB NOT NULL)");
            db.execSQL("CREATE INDEX idx_samples_created_at ON samples(created_at)");
            db.execSQL("CREATE TABLE locations (_id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER NOT NULL, payload_gzip BLOB NOT NULL)");
            db.execSQL("CREATE INDEX idx_locations_created_at ON locations(created_at)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    }
}
